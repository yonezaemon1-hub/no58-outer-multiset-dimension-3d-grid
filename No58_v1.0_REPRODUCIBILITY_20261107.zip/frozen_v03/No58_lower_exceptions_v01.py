"""No58: five additional corner-pattern families excluded for every N>=5.

Each site pattern uses z in {0,N}, so its pair below yields an identity of
three sorted distance values by direct substitution of L1 distance.
Only the parity of N affects the fifth pattern. This is a GENERAL-N
algebraic witness, with N=5..200 checked as a separate falsification test.
"""

def patterns(N):
    return [
        ((0,0,0),(0,1,N),(0,2,0)),
        ((0,0,0),(0,1,N),(1,0,N)),
        ((0,0,0),(0,2,0),(1,0,0)),
        ((0,0,0),(0,2,0),(1,1,0)),
        ((0,0,0),(0,2,N),(1,0,N)),
    ]

def witness(i,N):
    if i==0:return (1,0,0),(1,2,0)
    if i==1:return (0,1,0),(1,0,0)
    if i==2:return (1,2,0),(0,0,1)
    if i==3:return (1,0,0),(1,2,0)
    m=N//2
    if N%2:return (0,0,m),(1,0,m+1)
    return (0,0,m),(0,1,m+1)

def d(a,b):return sum(abs(x-y) for x,y in zip(a,b))

def main():
    for i in range(5):
        for N in range(5,201):
            S=set(patterns(N)[i]);u,v=witness(i,N)
            assert u!=v and u not in S and v not in S and 0<=u[2]<=N and 0<=v[2]<=N
            assert sorted(d(u,s) for s in S)==sorted(d(v,s) for s in S),(i,N,u,v)
        print(f'PASS exceptional family {i+1}/5 for all test N=5..200')
    print('ALGEBRAIC COLLISION FAMILIES: five parameter-independent templates or parity branches.')
    print('STATUS: conditional on classification; NO general exhaustion proof yet.')
if __name__=='__main__':main()
