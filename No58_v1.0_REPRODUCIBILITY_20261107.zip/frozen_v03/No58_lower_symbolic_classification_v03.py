"""Exact symbolic classification of 3-site sets with >=2 corners,
passing the unit-square necessary condition, in P2 x P3 x Pn (n>=3).
The third site's z is one of {0, t, N} with 0<t<N, where t is
symbolic. z labels 0,1,2 stand for {0, t, N}, not layer lengths.
Local-square equality depends only on membership in cuts, and thus on
these ordinal labels, not on the actual gap lengths. Reflecting z swaps
0,2 and fixes symbolic 1 (reparameterizes t -> N-t).
"""
from itertools import combinations,product
PLANE=list(product((0,1),(0,1,2)))
END=(0,2)
CORNERS=list(product((0,1),(0,2),END))
CANDIDATES=list(product((0,1),(0,1,2),(0,1,2)))

def canonical(t):
    t=tuple(t)
    if len(set(t))!=3:raise ValueError('duplicate site')
    return tuple(sorted(t))

def transforms(S):
    for i,j,k in product((0,1),repeat=3):
        yield canonical(((1-x if i else x,2-y if j else y,2-z if k else z) for x,y,z in S))

def cls(bits): return min(bits, bits^7)
def cut(S,axis,h):return cls(sum((1<<i) for i,p in enumerate(S) if p[axis]>=h))
def pass_local(S):
    x=cut(S,0,1); y1=cut(S,1,1);y2=cut(S,1,2)
    if x in (y1,y2): return False
    for z in (cut(S,2,1),cut(S,2,2)):
        if z in (x,y1,y2):return False
    return True

# Templates in ordinal coordinates, I=1 symbolizes arbitrary 0<t<N.
def base_patterns():
    ret=[]
    for z in (0,1,2):
        ret += [
            ((0,0,0),(0,0,2),(0,2,z)),  # A
            ((0,0,0),(0,0,2),(1,0,z)),  # B
            ((0,0,0),(1,2,0),(0,2,z)),  # C
        ]
    ret += [
        ((0,0,0),(0,1,2),(0,2,0)),
        ((0,0,0),(0,1,2),(1,0,2)),
        ((0,0,0),(0,2,0),(1,0,0)),
        ((0,0,0),(0,2,0),(1,1,0)),
        ((0,0,0),(0,2,2),(1,0,2)),
    ]
    return ret

# 3 corners or 2 corners + 1 arbitrary third site, types in ordinal z=0,1,2
raw=set()
for a,b in combinations(CORNERS,2):
    for c in CANDIDATES:
        if len({a,b,c})==3:raw.add(canonical((a,b,c)))
allowed={S for S in raw if pass_local(S)}
template={T for S in base_patterns() for T in transforms(S)}
print('total >=2-corner ordinal types',len(raw))
from collections import Counter
counts=Counter()
for S in allowed:
    corner=lambda p:p[1] in (0,2) and p[2] in (0,2)
    counts[(sum(corner(p) for p in S), any(p[2]==1 for p in S))]+=1
print('passing types',len(allowed),'by (corners,interior z):',dict(sorted(counts.items())))
print('template orbit closure',len(template))
print('missing templates',len(allowed-template),'bad extra templates',len(template-allowed))
for x in sorted(allowed-template):print('MISSING',x)
for x in sorted(template-allowed):print('EXTRA',x)
assert allowed==template
assert counts[(3,False)]==32
assert counts[(2,False)]==16
assert counts[(2,True)]==16
print('PASS: symbolic classification for any n>=3, any 0<t<N')
print('GENERAL COUNT: 16*(n-2) + 16 +32 = 16*n+16')
