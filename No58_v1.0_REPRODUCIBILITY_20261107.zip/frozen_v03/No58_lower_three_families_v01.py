"""No.58 analytic collision witnesses for three infinite 3-landmark families.

For N>=5 and any t in [0,N] these three sets all FAIL to be outer
multiset resolving sets on P2 x P3 x P_(N+1):
 A: {(0,0,0),(0,0,N),(0,2,t)}
 B: {(0,0,0),(0,0,N),(1,0,t)}
 C: {(0,0,0),(1,2,0),(0,2,t)}
Each routine below gives explicit vertices (u,v), with coordinate arithmetic
only. To make this a proof, substitute each branch into
  d((x,y,z),(a,b,c))=|x-a|+|y-b|+|z-c|.
Under the branch assumptions, all absolute values simplify to linear
expressions and the sorted triples match (permutation allowed).
The checks over n<=200 are additional falsification tests, not the proof.

This is NOT a proof that ALL 3-landmark sets fail: only three families.
"""

def A(N,t):
    if t==0:
        return (0,2,1),(1,0,0)
    if t==N:
        return (0,2,N-1),(1,0,N)
    if t%2==0:
        k=t//2
        return (0,0,k),(0,1,k+1)
    if N%2==1:
        h=(N+t)//2
        return (0,0,h),(0,1,h-1)
    m=N//2
    if t<m:
        return (0,1,m+1),(1,0,m-1)
    if t>m:
        return (0,1,m-1),(1,0,m+1)
    return (0,0,m-1),(0,0,m+1)


def B(N,t):
    if N%2==0:
        m=N//2
        if t<m:
            return (0,1,m-1),(1,0,m+1)
        if t>m:
            return (0,1,m+1),(1,0,m-1)
        return (0,0,m-1),(0,0,m+1)
    if t%2==1:
        k=(t-1)//2
        if k==0:
            return (0,1,0),(1,1,1)
        return (0,0,k),(1,0,k+1)
    if t==N-1:
        return (0,1,N),(1,1,N-1)
    h=(N+t+1)//2
    return (0,0,h),(1,0,h-1)


def C(N,t):
    if t==0:
        return (0,2,1),(1,0,0)
    if t%2==0:
        k=t//2
        return (0,0,k),(0,1,k+1)
    k=(t-1)//2
    return (0,0,k+1),(1,0,k)


def distance(u,s):
    return sum(abs(x-y) for x,y in zip(u,s))


def main():
    for name,witness in [('A',A),('B',B),('C',C)]:
        total=0
        for N in range(5,201):
            for t in range(N+1):
                if name=='A':
                    S={(0,0,0),(0,0,N),(0,2,t)}
                elif name=='B':
                    S={(0,0,0),(0,0,N),(1,0,t)}
                else:
                    S={(0,0,0),(1,2,0),(0,2,t)}
                u,v=witness(N,t)
                assert u!=v and u not in S and v not in S, (name,N,t,u,v,'landmark error')
                assert all(0<=s[0]<2 and 0<=s[1]<3 and 0<=s[2]<=N for s in (u,v)), (name,N,t,u,v,'bounds')
                sig1=sorted(distance(u,s) for s in S)
                sig2=sorted(distance(v,s) for s in S)
                assert sig1==sig2, (name,N,t,u,v,sig1,sig2)
                total+=1
        print(f'PASS family {name}: all N=5..200, all t=0..N; {total} explicit collisions')
    print('STATUS: THREE FAMILIES excluded for ALL N>=5 by explicit piecewise algebraic witnesses.')
    print('REMAINING: proving these families plus finitely many exceptions exhaust all metric bases.')

if __name__=='__main__':main()
