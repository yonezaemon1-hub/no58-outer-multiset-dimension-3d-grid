# Independent mathematical audit request — No.58 v0.3

Do NOT accept author-provided PASS labels as proof. Treat every claim as untrusted until independently checked. The objective is to find a counterexample, a missing case, or a flaw in the proposed **all-n** lower bound for outer multiset dimension of `P2 □ P3 □ Pn` (for `n>=6`).

## Inputs
- `No58_v03_GENERAL_LOWER_PROOF_CANDIDATE.md` (complete proof candidate)
- `No58_lower_corner_lemma_v03.cpp` and its stdout log
- `No58_lower_symbolic_classification_v03.py` and its stdout log
- `No58_lower_three_families_v01.py`, `No58_lower_exceptions_v01.py`
- `No58_upper_symbolic_proof_v01.py` and its re-run log
- `No58_v03_SHA256SUMS.txt`

## Required independent checks
1. Verify the definition of **outer** multiset resolving set. Distinguish it from metric dimension and ordinary multiset dimension. Check the usage of the known 3D-grid metric-dimension theorem.
2. Analyze the **empty-layer compression lemma** adversarially. Does every ordinary-distance collision at graph distance 2 or 4 in the shortened grid lift when both vertices lie below the removed layer, above it, or straddling it? Does deleting a site-free layer preserve the number of corner sites? Is the universal cutoff **35** rigorous?
3. Independently reimplement or manually audit the local-square sign-mask shortcut used in C++. In particular check the complement equivalence and that all z-cut masks are captured by breakpoints `1` and `z_i+1`.
4. Re-run the full `n=2..35` certificate (not a selected subset), ideally with another implementation, and seek any three-site S with <2 corners but with no ordinary collision of graph distance <=4.
5. Independently derive the **symbolic ordinal classification** for 3-site S with >=2 corners. Confirm 336 raw types, 64 accepted types, their decomposition (16 boundary 2-corner, 16 interior 2-corner per interior layer, 32 3-corner), and equality with the 3 parameterized families plus 5 exceptional forms under reflection. Check the argument works for arbitrary interior t, even if t is very close to 0 or N.
6. Do **not** accept checking `N<=200` as proof for the collision templates. For each branch in the proof document, independently simplify the absolute values under the stated integer constraints and confirm the printed common distance triple, that both witness vertices are in the graph, distinct, and not in the site set. Check that all parameter values are covered.
7. Re-evaluate the **four-site upper certificate** independently. Its symbolic tail argument, finite parity treatment, N=6 and N=8 exceptions, and exclusion of the sites themselves must be correct.
8. Examine whether the claimed result is already implied by 2022–2026 or earlier literature on outer multiset dimension, Cartesian products of paths, or cylindrical graphs. Distinguish discovery of a proof from novelty and prioritize exact equality statements.
9. Verify SHA256 on source and log files. Identify anything in the certificate that uses an unbounded heuristic, assertion-disabled configuration, inadequate datatype, or silent enumeration omission.

## Verdict format
Return separate MODEL / COMPRESSION / FINITE EXHAUSTIVENESS / SYMBOLIC CLASSIFICATION / COLLISION WITNESSES / UPPER BOUND / LITERATURE / NOVELTY / INTEGRITY status values (`PASS`, `FAIL`, `PARTIAL`, `INCONCLUSIVE`). Quote the smallest counterexample or concrete missing case where applicable. Do not authorize GitHub/Zenodo publication. All research remains HOLD pending an independent audit and the user's explicit release decision.
