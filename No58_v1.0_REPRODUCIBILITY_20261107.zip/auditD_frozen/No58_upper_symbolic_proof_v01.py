"""No.58 exploratory certificate, v0.1 (2026-11-06).

Claim checked, without quantifying over a finite range of n only:
  odim(P_2 square P_3 square P_n) <= 4 for every n >= 6.

This program checks explicit witnesses for n=6 and n=8, and verifies
symbolically (via a complete finite case reduction) two infinite families:
  odd n >= 7:  S={(0,0,0),(0,0,1),(0,0,n-1),(1,0,2)}
  even n >= 10: S={(0,0,0),(0,0,1),(0,0,n-1),(1,0,5)}

This is an *upper* certificate only. It does NOT establish odim >= 4.
It has not yet passed an independent external audit.

Proof of finite reduction:
Let N=n-1 and t=2 or 5. For vertex (x,y,z) put q=x+2y,
 a=x+y, b=1-x+y. Its four distances are
    a+z, a+|z-1|, a+N-z, b+|z-t|.
Their sum is
    N-t + 2*(q+max(z,t)+(z==0)).
Equal multisets require equal sums.

If one vertex has z<=t, the other must have z<=t+6 since q in 0..5.
Both z's are bounded; the only varying distance in N is a+N-z.
After N is large enough, this is larger than the three fixed distances.
Testing all N through that threshold and checking whether the two
three-constant multisets and the two N-offsets coincide is exhaustive.

If both vertices have z>t, equality of sums forces
    w=z+c, c=q(x,y)-q(x',y') in [-5,5].
For equal x,y we also have c=0, implying the same vertex, so exclude it.
Subtract z from all four distances. The two unordered lists are
    C1 union {a+h} and C2 union {a'+h-c},
where h=N-2*z, C1=[a,a-1,b-t],
      C2=[c+a',c+a'-1,c+b'-t].
The parity h == N modulo 2 is necessary. Unless both constant
three-multisets and variable offsets agree identically, every equality
forces at least one variable to coincide with an element of C1 or C2.
It suffices to check the finitely many resulting candidate h values.
No interval, floating-point, SMT, or external package is used.
"""
from collections import Counter
from itertools import product

if not __debug__:
    raise SystemExit("FAIL-CLOSED: Python -O disables certificate assertions")

H = tuple(product(range(2), range(3)))


def distances(x, y, z, N, t):
    a = x + y
    b = 1 - x + y
    return tuple(sorted((a + z, a + abs(z - 1), a + N - z, b + abs(z - t))))


def landmarks(N, t):
    return {(0, 0, 0), (0, 0, 1), (0, 0, N), (1, 0, t)}


def q(h):
    return h[0] + 2 * h[1]


def score(h, z, t):
    return q(h) + max(z, t) + int(z == 0)


def verify_infinite_family(t, Nmin):
    assert (t, Nmin) in ((2, 6), (5, 9))
    parity = Nmin % 2
    statistics = dict(low_pairs=0, low_N_tests=0, high_pairs=0, high_h_tests=0)

    # Case 1: at least one coordinate z is <= t.
    for h1 in H:
        for h2 in H:
            for z in range(t + 7):
                for w in range(t + 7):
                    if (h1, z) >= (h2, w):
                        continue
                    if min(z, w) > t:
                        continue
                    if score(h1, z, t) != score(h2, w, t):
                        continue
                    statistics['low_pairs'] += 1
                    a, a2 = sum(h1), sum(h2)
                    b = 1 - h1[0] + h1[1]
                    b2 = 1 - h2[0] + h2[1]
                    fixed1 = (a + z, a + abs(z - 1), b + abs(z - t))
                    fixed2 = (a2 + w, a2 + abs(w - 1), b2 + abs(w - t))
                    offset1, offset2 = a - z, a2 - w
                    # For N > B, N-dependent terms dominate all constants.
                    B = max(fixed1 + fixed2) - min(offset1, offset2) + 2
                    Nmax = max(Nmin + 2, max(z, w) + 2, B + 2)
                    for N in range(Nmin, Nmax + 1):
                        if N % 2 != parity or N < max(z, w):
                            continue
                        if (*h1, z) in landmarks(N, t) or (*h2, w) in landmarks(N, t):
                            continue
                        statistics['low_N_tests'] += 1
                        assert distances(*h1, z, N, t) != distances(*h2, w, N, t), (
                            'LOW COLLISION', t, N, h1, z, h2, w)
                    # For all larger N the equality reduces exactly to:
                    assert not (offset1 == offset2 and Counter(fixed1) == Counter(fixed2)), (
                        'LOW TAIL IDENTITY', t, h1, z, h2, w)

    # Case 2: both z > t; candidate collision depends only on h=N-2z.
    for i, h1 in enumerate(H):
        for h2 in H[i + 1:]:
            c = q(h1) - q(h2)
            a, a2 = sum(h1), sum(h2)
            b = 1 - h1[0] + h1[1]
            b2 = 1 - h2[0] + h2[1]
            constants1 = [a, a - 1, b - t]
            constants2 = [c + a2, c + a2 - 1, c + b2 - t]
            statistics['high_pairs'] += 1
            assert not (Counter(constants1) == Counter(constants2) and a == a2 - c), (
                'HIGH IDENTITY', t, h1, h2)
            constants = set(constants1 + constants2)
            candidates = {k - a for k in constants}
            candidates.update(k - (a2 - c) for k in constants)
            for hh in candidates:
                if hh % 2 != parity:
                    continue
                statistics['high_h_tests'] += 1
                assert Counter(constants1 + [a + hh]) != Counter(constants2 + [a2 + hh - c]), (
                    'HIGH COLLISION', t, h1, h2, hh)
    return statistics


def verify_direct(N, sites):
    assert len(sites) == len(set(sites)) == 4
    observed = set()
    for x in range(2):
        for y in range(3):
            for z in range(N + 1):
                if (x, y, z) in sites:
                    continue
                signature = tuple(sorted(sum(abs(a - b) for a, b in zip((x, y, z), v)) for v in sites))
                if signature in observed:
                    return False
                observed.add(signature)
    return True


def main():
    for t, Nmin in ((2, 6), (5, 9)):
        stats = verify_infinite_family(t, Nmin)
        print(f'PASS symbolic infinite family: t={t}, Nmin={Nmin}, {stats}')
    special = {
        6: ((0, 0, 0), (0, 0, 2), (0, 0, 5), (1, 0, 5)),
        8: ((0, 0, 0), (0, 0, 2), (0, 0, 7), (1, 0, 5)),
    }
    for n, sites in special.items():
        assert verify_direct(n - 1, sites), ('SPECIAL FAIL', n)
        print(f'PASS special witness n={n}, S={sites}')
    for n in range(7, 101):
        if n == 8:
            continue
        t = 2 if n % 2 else 5
        sites = tuple(sorted(landmarks(n - 1, t)))
        assert verify_direct(n - 1, sites), ('DIRECT FAIL', n)
    print('PASS direct cross-check n=7..100 except n=8 (separate witness)')
    for n in (200, 201, 1000, 1001):
        t = 2 if n % 2 else 5
        assert verify_direct(n - 1, tuple(sorted(landmarks(n - 1, t))))
    print('PASS direct spot checks n=200,201,1000,1001')
    print('RESULT: UPPER BOUND <=4 FOR ALL n>=6; LOWER BOUND IS NOT PROVED HERE')


if __name__ == '__main__':
    main()
