# No.58 v0.3 — General lower bound candidate for the outer multiset dimension of a 3D grid

Author: Ryutaro Yonezu — Independent Researcher  
Prepared: 2026-11-07  
Status: **INTERNAL COMPUTER-ASSISTED PROOF CANDIDATE; INDEPENDENT AUDIT PENDING; NOVELTY INCONCLUSIVE; RELEASE HOLD.**

## Claimed theorem (subject to independent audit)
For every integer `n >= 6`, writing `G_n = P_2 □ P_3 □ P_n`,

`odim(G_n) = 4`.

Here a subset `S` is *outer multiset resolving* if for any two distinct vertices `u,v` outside `S`, the unordered multisets of the distances from `u,v` to `S` are different. A three-site subset must fail; the four-site upper bound uses the separately provided upper certificate.

Coordinates are `(x,y,z)` with `x in {0,1}`, `y in {0,1,2}`, `z in {0,...,N}`, where `N=n-1`. Distance is Manhattan distance.

## Part I: lower bound, split on graph corners
A graph corner is `(x,y,z)` with `y in {0,2}` and `z in {0,N}`. There are 8 graph corners.

A multiset resolving set is also an ordinary (ordered) resolving set: if two complete ordered distance vectors agree, their unordered multisets agree. It is known independently that the ordinary metric dimension of a nontrivial 3D grid is three (Mora–Souto-Salorio–Tarrío-Tobar 2022), so it suffices to exclude 3-site sets.

### Lemma 1: every 3-site set with fewer than two corners fails ordinary resolving
Stronger: two vertices at graph distance exactly 2 or 4 have the same **ordered** three-component distance vector.

**Finite reduction, with complete lifting argument:** Consider any maximal interval of at least nine consecutive `z`-layers containing none of the three sites. Remove a layer `k` with at least four site-free layers on each side, and shift all layers above `k` down by one. Suppose that the shortened grid has an equal-ordered-distance pair `u',v'` with `d(u',v')<=4`.

* If both vertices are below `k`, lift them unchanged: for landmarks above `k` both distances increase by one, and all other distances remain unchanged.
* If both are on or above `k` in the shortened grid, lift both vertices up by one: for landmarks below `k` both distances increase by one, and all other distances remain unchanged.
* If they lie on opposite sides of the cut, their z-coordinates differ by at most four. Both z-coordinates therefore lie inside the same site-free run (because `k` has four empty layers to either side). Lift the two vertices with the **same** z-coordinates as in the shortened graph. Every landmark is strictly to one side or the other of both vertices, so the difference of their distances to each landmark remains unchanged.

In all three cases, a distinct pair of the same graph distance 2 or 4 and with identical ordered distance vectors lifts to the original graph. The number of corner landmarks is invariant under deletion of a site-free interior layer. Consequently a hypothetical counterexample (fewer than 2 corners; no short ordered collision) compresses to one with at most 35 layers: there are at most four runs of empty layers and at most three occupied layers; after repeated deletion every run has length at most eight, so `n <= 4*8 + 3 = 35`.

**Finite certificate:** `No58_lower_corner_lemma_v03.cpp` checks *every* triple with fewer than two corners for *every n=2,...,35*. It constructs the full Manhattan distance matrix. It first checks for local-square collisions, and otherwise compares the distance vectors for all vertex pairs at distance 2 or 4. The local-square shortcut is sound by the next paragraph. No triple survives.

**Local-square shortcut justification:** For a site `s_i`, crossing any unit edge at coordinate axis `j` and threshold `k` changes its distance to that site by `+1` or `-1` according to the side of `s_i`. Encode the three signs by a mask; identify a mask with its bitwise complement. If the sign masks of cuts along **two distinct coordinate directions** are equal up to complement, the corresponding unit square has a pair of opposite corners whose ordered three-distance vectors agree. These opposite corners have graph distance 2. The possible masks for all z-cuts only change at `z_i + 1`; hence checking the few breakpoints as the code does is exact. (There is no need to compare two cuts in the same direction.)

The C++ exhaustive certificate has no heuristic pruning and exhausts 13,921,300 triples with fewer than 2 corners across the 34 lengths. Of these, 13,864,044 have a square obstruction, and 57,256 are disposed of by direct distance-2-or-4 witnesses. Each rejected configuration has an actual short collision.

### Lemma 2: classification of the remaining triples via 336 symbolic types
Suppose a 3-site set has at least two corners. If there is a local-square obstruction it already fails. Otherwise fix the two corner sites. The third site has z-coordinate either `0`, `N`, or one intermediate coordinate `t`, `0<t<N`. Its x and y coordinates have only six possibilities.

For the unit-square obstruction, only the ordering `0 < t < N` matters, never the sizes of the gaps. Accordingly use the symbolic labels `0, I, N` and the x/y cuts together with the z-cuts between `0/I` and `I/N`. There are exactly 336 distinct 3-site ordinal types with at least 2 corners, comprising 16 types with exactly 2 corners and boundary z, 16 with exactly 2 corners and the symbolic interior z, 32 with exactly 3 corners, plus the types with an obstruction.

The checker `No58_lower_symbolic_classification_v03.py` enumerates the 336 types as finite sets, tests the exact unit-square condition (including complement masks) and compares the accepted set of 64 types with the closure under all eight coordinate reflections of the patterns below. Set equality is tested directly. Thus **for every `N>=5`**, every three-site configuration with at least two corners and without a square obstruction is, under an automorphism, one of the three families or five exceptions below.

Three parameterized families (`0<=t<=N`):

- `A(t) = {(0,0,0), (0,0,N), (0,2,t)}`
- `B(t) = {(0,0,0), (0,0,N), (1,0,t)}`
- `C(t) = {(0,0,0), (1,2,0), (0,2,t)}`

Five additional patterns:

- `E0 = {(0,0,0),(0,1,N),(0,2,0)}`
- `E1 = {(0,0,0),(0,1,N),(1,0,N)}`
- `E2 = {(0,0,0),(0,2,0),(1,0,0)}`
- `E3 = {(0,0,0),(0,2,0),(1,1,0)}`
- `E4 = {(0,0,0),(0,2,N),(1,0,N)}`

The exact accepted counts by location are `(2 corners, third at boundary)=16`, `(2 corners, third at interior t)=16 per t`, `(3 corners)=32`; hence the total is `16*(n-2)+16+32=16n+16`. This matches but does not assume previous finite metric-basis counts.

### Lemma 3: all eight normal forms fail outer multiset resolution
Below a witness `(u,v)` always consists of **two distinct vertices outside S**, with exactly the same unordered multiset of three distances to S. The identities hold for all `N>=5` with branch conditions given. They are checked by inserting the coordinates into `d((x,y,z),(a,b,c))=|x-a|+|y-b|+|z-c|` and simplifying the absolute values under the branch inequalities. The Python witnesses in the accompanying scripts additionally test all `N=5,...,200` and all eligible `t`, but the intended mathematical proof is the direct case-by-case algebraic identities, not extrapolation from these finite tests.

#### Family A
- `t=0`: `u=(0,2,1), v=(1,0,0)`; common distances `{1,3,N+1}`.
- `t=N`: `u=(0,2,N-1), v=(1,0,N)`; common distances `{1,3,N+1}`.
- `t=2k` with `1<=k` and `2k<N`: `u=(0,0,k), v=(0,1,k+1)`; common distances `{k,k+2,N-k}`.
- `N=2m+1`, `t=2k+1` with `0<=k<=m-1`: `h=m+k+1`; `u=(0,0,h),v=(0,1,h-1)`; common distances `{h,m-k,m-k+2}`.
- `N=2m`, `t` odd and `t<m`: `u=(0,1,m+1),v=(1,0,m-1)`; common distances `{m,m+2,m+2-t}`.
- `N=2m`, `t` odd and `t>m`: `u=(0,1,m-1),v=(1,0,m+1)`; common distances `{m,m+2,t-m+2}`.
- `N=2m`, `t=m` (necessarily odd in the residual branch): `u=(0,0,m-1),v=(0,0,m+1)`; common distances `{m-1,m+1,3}`.

#### Family B
- `N=2m`, `t<m`: `u=(0,1,m-1),v=(1,0,m+1)`; common distances `{m,m+2,m+1-t}`.
- `N=2m`, `t>m`: `u=(0,1,m+1),v=(1,0,m-1)`; common distances `{m,m+2,t-m+1}`.
- `N=2m`, `t=m`: `u=(0,0,m-1),v=(0,0,m+1)`; common distances `{m-1,m+1,2}`.
- `N=2m+1`, `t=1`: `u=(0,1,0),v=(1,1,1)`; common distances `{1,3,N+1}`.
- `N=2m+1`, `t=2k+1`, `k>=1`: `u=(0,0,k),v=(1,0,k+1)`; common distances `{k,k+2,N-k}`.
- `N=2m+1`, `t=N-1`: `u=(0,1,N),v=(1,1,N-1)`; common distances `{1,3,N+1}`.
- `N=2m+1`, `t=2k<N-1`: `h=m+k+1`; `u=(0,0,h),v=(1,0,h-1)`; common distances `{h,m-k,m-k+2}`.

#### Family C
- `t=0`: `u=(0,2,1),v=(1,0,0)`; common distances `{1,2,3}`.
- `t=2k>=2`: `u=(0,0,k),v=(0,1,k+1)`; common distances `{k,k+2,k+3}`.
- `t=2k+1`: `u=(0,0,k+1),v=(1,0,k)`; common distances `{k+1,k+2,k+4}`.

#### Five exceptional patterns
- `E0`: `u=(1,0,0),v=(1,2,0)`; common distances `{1,3,N+2}`.
- `E1`: `u=(0,1,0),v=(1,0,0)`; common distances `{1,N,N+2}`.
- `E2`: `u=(1,2,0),v=(0,0,1)`; common distances `{1,2,3}`.
- `E3`: `u=(1,0,0),v=(1,2,0)`; common distances `{1,1,3}`.
- `E4`, `N=2m+1`: `u=(0,0,m),v=(1,0,m+1)`; common distances `{m,m+2,m+3}`.
- `E4`, `N=2m`: `u=(0,0,m),v=(0,1,m+1)`; common distances `{m,m+1,m+2}`.

Since automorphisms preserve distance multisets and the condition of being outside S, all three-site sets with at least two corners fail outer resolution.

### Conclusion
Lemmas 1–3 exclude every three-site set. The ordinary metric dimension lower bound excludes smaller sets. Therefore `odim(G_n)>=4` for all `n>=6` (computer-assisted proof candidate).

## Part II: upper bound
The earlier `No58_upper_symbolic_proof_v01.py` verifies a four-site witness for every `n>=6` by a finite exact reduction in the sums of distances and by explicit exceptions `n=6,8`. It was re-run in the current session. The candidate lower and upper bounds give the stated exact value, **provided both certificates pass independent audit**.

## Integrity and limits
- No large-n extrapolation is used for Lemma 1: the finite threshold is justified by an explicit collision-lifting lemma.
- The symbolic ordinal classification is genuinely independent of `n` and of the location of interior `t`, since only unit-cut masks enter its necessary condition.
- The algebraic witness identities are asserted over all parameter values in the stated branches; finite N test scripts are *supporting* checks, not a substitute for their algebraic verification.
- **Independent AI mathematical audit: NOT DONE. Human peer review: NOT DONE. Novelty against full literature: INCONCLUSIVE. GitHub/Zenodo release: HOLD.**
- This new 3D-grid candidate is **not** the earlier duplicate No.58 prism forcing paper; that prior duplicate remains NOT ADOPTED.
