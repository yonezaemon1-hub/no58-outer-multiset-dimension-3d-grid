#!/usr/bin/env python3
"""No.58 Audit B. Independent geometric unit-square enumeration.

NO import of any author verification module. Uses physical grid distances,
not sign masks. Checks abstract orbit certificate against physical square
collisions, including near-boundary interior layers.
"""
from itertools import combinations, product
from collections import Counter, defaultdict

Plane = tuple(product(range(2),range(3)))
AbstractV = tuple(product(range(2),range(3),range(3)))
C = {v for v in AbstractV if v[1] in (0,2) and v[2] in (0,2)}

def require(ok, message):
    if not ok: raise RuntimeError(message)

def norm(S): return tuple(sorted(S))

def to_phys(S, N, t):
    return norm((x,y,(0,t,N)[z]) for (x,y,z) in S)

def ds(v,S):
    return tuple(sum(abs(a-b) for a,b in zip(v,s)) for s in S)

def local_square_witness(S,N):
    lens=(2,3,N+1)
    for axis1,axis2 in combinations(range(3),2):
        for b in product(*(range(lens[a]-(a in (axis1,axis2))) for a in range(3))):
            a=list(b); a[axis1]+=1
            d=list(b); d[axis2]+=1
            c=list(a); c[axis2]+=1
            a,c,d=tuple(a),tuple(c),tuple(d)
            if ds(b,S)==ds(c,S): return (b,c)
            if ds(a,S)==ds(d,S): return (a,d)
    return None

def reflect(S, bx,by,bz):
    return norm(((1-x if bx else x),(2-y if by else y),(2-z if bz else z)) for x,y,z in S)

def orbit(S):
    return {reflect(S,bx,by,bz) for bx,by,bz in product((0,1),repeat=3)}

raw = {norm(S) for S in combinations(AbstractV,3) if len(set(S)&C)>=2}
require(len(raw)==336, f'raw types count = {len(raw)}')

# Classify at a physical scale without symbolic sign masks or original code.
reference = {S for S in raw if local_square_witness(to_phys(S,6,2),6) is None}
require(len(reference)==64, f'physical accepted count = {len(reference)}')

# Numerical layer spacings must not affect symbolic classification.
physical_cases=0
for N in (3,4,5,6,7,8,9,12):
    for t in range(1,N):
        got={S for S in raw if local_square_witness(to_phys(S,N,t),N) is None}
        require(got==reference, f'DISCREPANCY N={N},t={t}, missing={reference-got},extra={got-reference}')
        physical_cases += len(raw)

# Count all types and decompose by corner count and whether there is an interior site.
categories=Counter((len(set(S)&C),int(any(z==1 for x,y,z in S))) for S in reference)
require(categories=={(2,0):16,(2,1):16,(3,0):32}, str(categories))

# Author's eight named patterns, independently compared with geometric classification.
def T(*x):return norm(x)
family_patterns={}
for z in (0,1,2):
    family_patterns[f'A(z={z})']=T((0,0,0),(0,0,2),(0,2,z))
    family_patterns[f'B(z={z})']=T((0,0,0),(0,0,2),(1,0,z))
    family_patterns[f'C(z={z})']=T((0,0,0),(1,2,0),(0,2,z))
family_patterns.update({
 'E0':T((0,0,0),(0,1,2),(0,2,0)),
 'E1':T((0,0,0),(0,1,2),(1,0,2)),
 'E2':T((0,0,0),(0,2,0),(1,0,0)),
 'E3':T((0,0,0),(0,2,0),(1,1,0)),
 'E4':T((0,0,0),(0,2,2),(1,0,2))
})
covered=set().union(*(orbit(S) for S in family_patterns.values()))
require(covered==reference, f"orbit mismatch: extra={len(covered-reference)} missing={len(reference-covered)}")

# Partition all physically valid types into reflection orbits, record witness labels.
remaining=set(reference); orbits=[]
while remaining:
    rep=min(remaining)
    o=orbit(rep)
    require(o<=reference, "invalid orbit")
    remaining-=o
    names=sorted(name for name,S in family_patterns.items() if S in o)
    require(bool(names), "unexplained orbit")
    orbits.append((rep,len(o),names))

print('PASS: 336 raw types (>= 2 corners; 3-site sets)')
print('PASS: 64 types without unit-square ordered-distance collision')
print('PASS: independent direct distance geometry, no sign mask shortcut')
print(f'PASS: equality at 336 configurations * {physical_cases//336} physical (N,t) settings = {physical_cases} classifications')
print('PASS: (corner count, interior flag) ->',dict(sorted(categories.items())))
print('PASS: reflected closure of A(t),B(t),C(t),E0,...,E4 equals all 64 types')
print('Reflection orbits:',len(orbits))
for rep,card,names in orbits:
    print(f'  size={card} rep={rep} template={",".join(names)}')
print('GENERAL: 16*(n-2)+16+32 = 16*n+16 for n>=3')
