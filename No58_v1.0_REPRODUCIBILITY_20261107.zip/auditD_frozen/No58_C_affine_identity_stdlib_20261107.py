#!/usr/bin/env python3
"""No.58 Audit C: standard-library-only exact affine coefficient verifier.
Every parameter is a nonnegative integer; abs signs are proved coefficientwise.
"""
from dataclasses import dataclass
from collections import Counter

@dataclass(frozen=True)
class Aff:
    const:int=0
    cp:int=0
    cq:int=0
    cr:int=0
    def __add__(self,b):
        b=af(b)
        return Aff(*(x+y for x,y in zip(self.coef(),b.coef())))
    __radd__=__add__
    def __neg__(self):return Aff(*(-x for x in self.coef()))
    def __sub__(self,b):return self + (-af(b))
    def __rsub__(self,b):return af(b) + (-self)
    def __mul__(self,b):
        if not isinstance(b,int):raise TypeError('affine multiplication requires an integer')
        return Aff(*(b*x for x in self.coef()))
    __rmul__=__mul__
    def coef(self):return (self.const,self.cp,self.cq,self.cr)
    def __str__(self):
        parts=[str(self.const)] if self.const else []
        for a,v in ((self.cp,'p'),(self.cq,'q'),(self.cr,'r')):
            if a:parts.append(f'{a}*{v}')
        return ' + '.join(parts) if parts else '0'

def af(v):
    if isinstance(v,Aff):return v
    if isinstance(v,int):return Aff(v)
    raise TypeError(f'not an affine integer {v!r}')

p,q,r=Aff(0,1),Aff(0,0,1),Aff(0,0,0,1)

def require(ok,*msg):
    if not ok:raise RuntimeError('FAIL '+ ' '.join(map(str,msg)))

def prove_nonnegative(expr):
    return all(a>=0 for a in af(expr).coef())

def prove_strict(expr):
    a=af(expr)
    return prove_nonnegative(a) and a.const>0

def abs_exact(expr):
    expr=af(expr)
    if prove_nonnegative(expr):return expr
    if prove_nonnegative(-expr):return -expr
    raise RuntimeError(f'absolute-value sign not proved: {expr}')

def d(a,b):return sum((abs_exact(a[i]-b[i]) for i in range(3)),af(0))

def distinct(a,b):return any(prove_strict(a[i]-b[i]) or prove_strict(b[i]-a[i]) for i in range(3))

def bounded_vertex(v,N):
    return all(prove_nonnegative(v[i]) and prove_nonnegative(h-v[i]) for i,h in enumerate((1,2,N)))

def aud(name,N,t,S,u,v):
    N,t=af(N),af(t)
    require(prove_nonnegative(N-1),name,'N>=1')
    require(prove_nonnegative(t) and prove_nonnegative(N-t),name,'0<=t<=N')
    require(len(S)==3 and all(distinct(S[i],S[j]) for i in range(3) for j in range(i+1,3)),name,'duplicate sites')
    require(all(bounded_vertex(vv,N) for vv in (u,v,*S)),name,'vertex bounds')
    require(distinct(u,v),name,'same witness endpoints')
    require(all(distinct(w,s) for w in (u,v) for s in S),name,'witness endpoint in S')
    lhs=Counter(d(u,s) for s in S)
    rhs=Counter(d(v,s) for s in S)
    require(lhs==rhs,name,'distance mismatch',lhs,rhs)
    return {'case':name,'identity':','.join(sorted(str(x) for x in lhs.elements()))}

cases=[]
def add(name,N,t,S,u,v):cases.append(aud(name,N,t,S,u,v))

def A(N,t):return ((0,0,0),(0,0,N),(0,2,t))
def B(N,t):return ((0,0,0),(0,0,N),(1,0,t))
def C(N,t):return ((0,0,0),(1,2,0),(0,2,t))

def E(j,N):
    return [((0,0,0),(0,1,N),(0,2,0)),
        ((0,0,0),(0,1,N),(1,0,N)),
        ((0,0,0),(0,2,0),(1,0,0)),
        ((0,0,0),(0,2,0),(1,1,0)),
        ((0,0,0),(0,2,N),(1,0,N))][j]

# Each slack p,q,r is a FREE nonnegative integer. Branches sometimes
# encompass a slightly larger valid domain than required; this is safe.
# A(t): 7 branches. All actual inputs N>=5 fall in these domains.
N=5+p;add('A t=0',N,0,A(N,0),(0,2,1),(1,0,0))
N=5+p;add('A t=N',N,N,A(N,N),(0,2,N-1),(1,0,N))
k=1+p;t=2*k;N=t+1+q
add('A interior even t',N,t,A(N,t),(0,0,k),(0,1,k+1))
k=p;m=k+1+q;N=2*m+1;t=2*k+1;h=m+k+1
add('A N odd, interior odd t',N,t,A(N,t),(0,0,h),(0,1,h-1))
t=1+p;m=t+1+q;N=2*m
add('A N even, odd t<m',N,t,A(N,t),(0,1,m+1),(1,0,m-1))
m=2+p+q;t=m+1+p;N=2*m
add('A N even, odd t>m',N,t,A(N,t),(0,1,m-1),(1,0,m+1))
m=3+p;t=m;N=2*m
add('A N even, odd t=m',N,t,A(N,t),(0,0,m-1),(0,0,m+1))

# B(t): three N-even branches, four N-odd branches.
t=p;m=t+1+q;N=2*m
add('B N even t<m',N,t,B(N,t),(0,1,m-1),(1,0,m+1))
m=2+p+q;t=m+1+p;N=2*m
add('B N even t>m',N,t,B(N,t),(0,1,m+1),(1,0,m-1))
m=3+p;t=m;N=2*m
add('B N even t=m',N,t,B(N,t),(0,0,m-1),(0,0,m+1))
m=2+p;N=2*m+1;t=1
add('B N odd t=1',N,t,B(N,t),(0,1,0),(1,1,1))
k=1+p;m=k+q;N=2*m+1;t=2*k+1
add('B N odd t odd>=3',N,t,B(N,t),(0,0,k),(1,0,k+1))
m=2+p;N=2*m+1;t=N-1
add('B N odd t=N-1',N,t,B(N,t),(0,1,N),(1,1,N-1))
k=p;m=k+1+q;N=2*m+1;t=2*k;h=m+k+1
add('B N odd t even<N-1',N,t,B(N,t),(0,0,h),(1,0,h-1))

# C(t): t=0, positive even, or odd. For even/odd N=t+q.
N=5+p;add('C t=0',N,0,C(N,0),(0,2,1),(1,0,0))
k=1+p;t=2*k;N=t+q
add('C t positive even',N,t,C(N,t),(0,0,k),(0,1,k+1))
k=p;t=2*k+1;N=t+q
add('C t odd',N,t,C(N,t),(0,0,k+1),(1,0,k))

# Five exceptional boundary-corner patterns; E4 is parity-split.
N=5+p
add('E0',N,0,E(0,N),(1,0,0),(1,2,0))
add('E1',N,0,E(1,N),(0,1,0),(1,0,0))
add('E2',N,0,E(2,N),(1,2,0),(0,0,1))
add('E3',N,0,E(3,N),(1,0,0),(1,2,0))
m=2+p;N=2*m+1
add('E4 N odd',N,0,E(4,N),(0,0,m),(1,0,m+1))
m=3+p;N=2*m
add('E4 N even',N,0,E(4,N),(0,0,m),(0,1,m+1))

require(len(cases)==23, 'wrong case count',len(cases),[x['case'] for x in cases])
for entry in cases:
    print('PASS',entry['case'],'exact sorted multiset identity',entry['identity'])
print('PASS:',len(cases),'affine branch identities; independent exterior, bounds and signs certified over all nonnegative integer slack variables')
