#!/usr/bin/env python3
"""Simple physical cross-check and negative controls for upper audit D (no imports)."""
from collections import defaultdict

def require(ok,msg):
    if not ok:raise RuntimeError('FAIL: '+str(msg))

def signature(p,sites):
    return tuple(sorted(sum(abs(p[j]-s[j]) for j in range(3)) for s in sites))

def family_sites(n):
    N=n-1
    if n==6:return ((0,0,0),(0,0,2),(0,0,5),(1,0,5))
    if n==8:return ((0,0,0),(0,0,2),(0,0,7),(1,0,5))
    t=2 if n%2 else 5
    return ((0,0,0),(0,0,1),(0,0,N),(1,0,t))

def check(n,sites):
    seen={}
    for x in range(2):
        for y in range(3):
            for z in range(n):
                p=(x,y,z)
                if p in sites:continue
                sig=signature(p,sites)
                if sig in seen:return (seen[sig],p,sig)
                seen[sig]=p
    return None

def main():
    for n in range(6,202):
        S=family_sites(n)
        require(len(S)==len(set(S))==4,(n,'invalid sites'))
        for x,y,z in S:require(0<=x<2 and 0<=y<3 and 0<=z<n,'out of bounds')
        require(check(n,S) is None,(n,'not resolving',check(n,S)))
    for n in (1000,1001):
        require(check(n,family_sites(n)) is None,(n,'not resolving'))
    print('PASS physical cross-check: all n=6..201, plus n=1000,1001')
    # Deliberately use the wrong parity in the infinite templates.
    for n,t in ((8,2),(9,5)):
        N=n-1
        S=((0,0,0),(0,0,1),(0,0,N),(1,0,t))
        found=check(n,S)
        require(found is not None,('mutation not rejected',n,t))
        print('PASS wrong-parity negative control n=',n,'t=',t,'collision=',found)
    # Correct two exceptional n must be good.
    require(check(6,family_sites(6)) is None,'exception n6')
    require(check(8,family_sites(8)) is None,'exception n8')
    print('PASS: special n=6,8 constructions and mutation rejection')

if __name__=='__main__':main()
