// Independent exhaustive check for audit A: no sign-mask shortcut.
// For each landmark s, bitmask records every pair u,v at graph distance
// 2 or 4 with exactly equal ordered distances from s. For a triple of
// landmarks, common set bits represent certified collision pairs.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
using P = array<int,3>;
int dist(const P &a, const P &b) {
  return abs(a[0]-b[0])+abs(a[1]-b[1])+abs(a[2]-b[2]);
}
int main(){
  uint64_t grand=0;
  for(int n=2;n<=35;++n){
    vector<P> vs;
    for(int z=0;z<n;++z)for(int y=0;y<3;++y)for(int x=0;x<2;++x)
      vs.push_back({x,y,z});
    const int v=int(vs.size());
    vector<pair<int,int>> pairs;
    for(int a=0;a<v;++a)for(int b=a+1;b<v;++b){
      int d=dist(vs[a],vs[b]);
      if(d==2||d==4)pairs.emplace_back(a,b);
    }
    const int words=(int(pairs.size())+63)/64;
    vector<vector<uint64_t>> same(v,vector<uint64_t>(words,0));
    for(int i=0;i<(int)pairs.size();++i){
      auto [u,w]=pairs[i];
      for(int s=0;s<v;++s)
        if(dist(vs[u],vs[s])==dist(vs[w],vs[s]))
          same[s][i>>6]|=uint64_t(1)<<(i&63);
    }
    vector<int> corners(v,0);
    for(int s=0;s<v;++s){
      auto [x,y,z]=vs[s];
      (void)x;
      corners[s]=int((y==0||y==2)&&(z==0||z==n-1));
    }
    uint64_t count=0;
    for(int a=0;a<v;++a)for(int b=a+1;b<v;++b){
      int ab=corners[a]+corners[b];
      if(ab>=2) continue;
      vector<uint64_t> common(words,0);
      bool any=false;
      for(int w=0;w<words;++w){
        common[w]=same[a][w]&same[b][w];
        any|=(common[w]!=0);
      }
      if(!any){
        cout << "FAIL: no collision shared by pair, n="<<n<<", a="<<a<<", b="<<b<<"\n";
        return 2;
      }
      for(int c=b+1;c<v;++c){
        if(ab+corners[c]>=2)continue;
        ++count;
        bool collision=false;
        for(int w=0;w<words;++w)
          if((common[w]&same[c][w])!=0){collision=true;break;}
        if(!collision){
          cout << "FAIL: no short collision n="<<n<<" S="<<a<<","<<b<<","<<c<<"\n";
          return 3;
        }
      }
    }
    cout<<"PASS n="<<n<<" checked="<<count<<" pairs="<<pairs.size()<<'\n';
    grand+=count;
  }
  cout<<"PASS all n=2..35 checked="<<grand<<"\n";
}
