#!/usr/bin/env python3
"""Fail-closed sanity checks for No58 Audit C. No source file mutated."""
import contextlib, io, runpy

with contextlib.redirect_stdout(io.StringIO()):
    ns=runpy.run_path('No58_C_affine_identity_stdlib_20261107.py')
N=5+ns['p']; A=ns['A']; aud=ns['aud']
try:
    aud('MUTATED_A_t0',N,0,A(N,0),(0,2,2),(1,0,0))
except RuntimeError as e:
    if 'distance mismatch' not in str(e):
        raise RuntimeError('Unexpected error in mutation test') from e
    print('PASS mutation of collision endpoint rejected by symbolic certificate')
else:
    raise RuntimeError('FAIL: mutation silently accepted')

with contextlib.redirect_stdout(io.StringIO()):
    cs=runpy.run_path('No58_C_physical_orbit_witness_audit_20261107.py')
S=((0,0,0),(0,0,5),(0,2,0))
if cs['good_witness'](S,(0,2,2),(1,0,0),5):
    raise RuntimeError('FAIL: mutated physical witness accepted')
print('PASS mutation of collision endpoint rejected by physical checker')
