# No.58 — Audit D: upper-bound proof and complete theorem assembly

**Date:** 2026-11-07 (JST)  
**Research author:** Ryutaro Yonezu — Independent Researcher  
**Status:** **INTERNAL MATHEMATICAL AUDIT PASS (computer-assisted)**; **external AI audit NOT DONE**; **novelty INCONCLUSIVE**; **publication HOLD**.  
**Subject:** `G_n = P_2 □ P_3 □ P_n`, `n ≥ 6`, with outer multiset dimension `odim`.

## 1. Exact theorem examined

For every integer `n≥6`,

`odim(P_2 □ P_3 □ P_n) = 4`.

Coordinates `(x,y,z)` run through `x∈{0,1}`, `y∈{0,1,2}`, `z∈{0,...,n-1}`. Graph distances are Manhattan distances. An outer multiset resolving set `S` distinguishes **only vertices outside S**, by unordered multisets of distances to the landmarks in `S`.

## 2. Audit D: independently established four-point upper bound

Write `N=n-1`. Use:

- Odd `n≥7` (`N=6+2k`, `k≥0`): `S={(0,0,0),(0,0,1),(0,0,N),(1,0,2)}`.
- Even `n≥10` (`N=9+2k`, `k≥0`): `S={(0,0,0),(0,0,1),(0,0,N),(1,0,5)}`.
- Special `n=6`: `S={(0,0,0),(0,0,2),(0,0,5),(1,0,5)}`.
- Special `n=8`: `S={(0,0,0),(0,0,2),(0,0,7),(1,0,5)}`.

### 2.1 Independent *exact rational permutation* method

The new `No58_D_upper_exact_permutation_audit.py` **does not** import or invoke the original sum-of-distances reduction `No58_upper_symbolic_proof_v01.py`.

For each infinite family, any two candidate vertices `(x,y,z)`, `(x',y',w)` have horizontal positions in the 6-element set `{0,1}×{0,1,2}`. There are `C(6,2)+6 = 21` unordered horizontal position-pairs, including identical horizontal coordinates. Each z-position lies in exactly one region: `z=0`, `1≤z≤t`, or `t+1≤z≤N`; analogously for `w`. This gives `21 × 3 × 3 × 4! = 4,536` exhaustive cases per family.

On each region, all four landmark distances are **affine integer expressions** in `(k,z,w)`, where `N=N_min+2k`. Equality of unordered multisets is equivalent to equality under at least one of 24 permutations. For coincident horizontal coordinates, impose `w≥z+1` to exclude identical vertices. Explicit integer bounds include `k≥0`, `0≤z,w≤N`, and the region bounds.

For each case, use exact `fractions.Fraction` reduced-row-echelon elimination for the 4 distance equalities, then exact rational Fourier–Motzkin elimination for the resulting linear inequalities. Every real-infeasible case is rejected without any numerical floating-point tolerance. The remaining real-feasible cases are checked for integer feasibility by symbolic affine parameterization.

| Exact outcome | Odd n≥7 (t=2) | Even n≥10 (t=5) |
|---|---:|---:|
| All unordered positions × regions × permutations | 4,536 | 4,536 |
| Equality system inconsistent | 3,828 | 4,026 |
| Equalities consistent, inequalities real-infeasible | 702 | 507 |
| Real-feasible systems | 6 | 3 |
| Integer-feasible collisions | **0** | **0** |

In all 6 remaining odd-family cases, the RREF imposes `k=w−7/2` and `z=w+1`. Since both `k` and `w` are integers, this is impossible. Equivalently `2w=N+1` with even `N`.

In all 3 remaining even-family cases, RREF gives `k=w−13/2` and `z=w+1`, again impossible for integers. Equivalently `2w=N+4` with odd `N`.

Hence both stated infinite upper constructions are **injective even on all vertices**, stronger than the outer-only requirement. The two small exceptions are checked directly by independent Manhattan-distance computation.

### 2.2 Direct physical and mutation checks

`No58_D_direct_crosscheck_and_mutation.py` tests all `6≤n≤201`, plus `n=1000,1001`, with the actual outer definition. All succeed.

As negative controls, deliberately applying `t=2` at `n=8` produces a genuine outside collision `(0,0,5)` and `(1,0,4)`; applying `t=5` at `n=9` produces `(0,0,7)` and `(1,0,6)`. The checker rejects both. Explicit special witnesses for `n=6,8` are separately accepted.

### 2.3 Comparison with original certificate

The independently written proof route and the original `No58_upper_symbolic_proof_v01.py` both execute successfully. The original uses sum-of-distances reductions; Audit D uses exact permutation/linear-inequality elimination. The two do not share their proof pruning logic.

## 3. Full lower-bound assembly from Audits A+B+C

### 3.1 Sets with fewer than two graph corners — Audit A

Audit A proves: every triple containing fewer than two corners of `P_2 □ P_3 □ P_n` has a pair of distinct vertices at graph distance 2 or 4 with **the same ordered distance vector** to all three landmarks. Such a pair cannot contain a landmark, so it is also an outer-multiset collision.

Its empty-layer deletion lemma lifts such a short collision from a reduced graph to the original graph. Every site-free run with length≥9 can be shortened by one; with three occupied layers there are at most four runs, giving a finite reduction to `n≤3+4×8=35`.

The independent C++17 bitset checker was recompiled with `-O3 -Wall -Wextra -Werror -pedantic` and run again in Audit D: `n=2..35`, **13,921,300 triples, no survivors**. It uses no symbolic/local-square shortcut.

### 3.2 Sets with at least two graph corners — Audit B

With a two-corner anchor, a third landmark's longitudinal layer is represented by `0`, `I`, or `N`. There are `C(8,2)×10 + C(8,3)=336` 3-point ordinal types. The local unit-square obstruction depends only on the z-order, not on the gap lengths. Independent physical square enumeration and reflection-orbit classification leave **64** types, all covered by three families `A(t), B(t), C(t)` and five exceptional templates `E0..E4` under eight graph reflections.

Audit D re-ran the independent geometric checker: **336 raw types, 64 survivors, 15,456 physical parameter cross-checks**, all PASS. This is a necessary-condition classification, not a false claim of all ordinary metric bases.

### 3.3 Explicit outside collisions — Audit C

For each of the 23 branches of the eight normal forms, the independent affine-arithmetic verifier certifies that the proposed collision endpoints are distinct, in range, **outside the landmark set**, and share the same unordered distance multiset over all admissible integer parameters. Audit D re-ran the standard-library exact checker: **23/23 PASS**.

Audit D also re-ran the independent physical-orbit checker for `n=6..61`: **305,760** ≥2-corner triples enumerated, **30,912** surviving local obstructions, and **30,912** concrete outside collisions witnessed. The all-n conclusion rests on the symbolic Audit B classification and symbolic Audit C identities, not on finite extrapolation.

### 3.4 The ≤2-landmark case, without external literature

For any two landmarks, consider any unit cube (all three factors have ≥2 vertices). On each of its three coordinate axes, the pair of changes in distances to the two landmarks forms a sign vector in `{−1,+1}²`. There are only **two classes modulo sign reversal**. Two of the three axes therefore have equal or opposite sign vectors. The diagonal opposite vertices of the corresponding unit square have identical ordered distance vectors to the two landmarks. Hence **no two-point set is an ordinary resolving set**. An outer-multiset resolving set is always an ordinary resolving set because an ordered collision among two vertices outside the set is also an unordered collision, whereas each landmark has its uniquely placed zero coordinate in the ordered representation. Therefore outer-multiset dimension is at least 3. One or zero landmark cannot do better than two; ordinary resolving sets are monotone under adding landmarks.

Audits A+B+C further exclude every three-landmark set. Consequently `odim(G_n)≥4` for all `n≥6`. Together with the four-landmark upper construction, `odim(G_n)=4` follows.

## 4. Integrity and reproduction

- The original v0.3 12-entry SHA256 manifest and Audits A/B/C SHA256 manifests were checked in Audit D, **all matching** their current corresponding source/log files.
- Original v0.3 ZIP and A/B/C ZIPs passed ZIP integrity checks.
- A C++ finite exhaustiveness, B geometric classification, C affine identities, C physical orbit coverage, original upper certificate, and D independent exact upper certificate were all re-run this session and PASS.
- Audit D's own files and hashes are recorded in `SHA256SUMS.txt` in the package. Nothing in v0.3 or A/B/C was modified during Audit D.

## 5. Scope and limitations

1. **Mathematical proof candidate:** Internal computer-assisted theorem assembly **PASS** under the audited algorithms and reductions above. The analysis does not constitute an independent Claude audit, formal Lean proof, or human peer review.
2. **New approach to upper bound:** Independent exact rational verification confirms the 4-point constructions. The lower bound relies on A/B/C existing certificates and their separately implemented checks.
3. **Novelty:** **INCONCLUSIVE.** Preliminary literature searches examined 2019 outer multiset dimension, 2023 2D grid formula, the July 2026 multiset-resolvability survey, and recent 2026 toroidal-grid/corona-product papers. No directly identical general 3D narrow-grid theorem was identified in that limited search. This is *not* a comprehensive priority audit, and further reference chasing remains required.
4. **Windows:** The user independently reproduced Audit C on Windows PowerShell 5.1 (log timestamp 2026-11-07 01:34 JST). Audit D itself has **not yet** been tested on the user's Windows machine.
5. **Publication:** **HOLD** pending separate AI audit, deeper prior-art check, Windows Audit D re-run, and the user's explicit release authorization.

The earlier abandoned No.58 prism-graph forcing candidate was a duplicate of prior No.43 and stays NOT ADOPTED. This is an unrelated new candidate using the same number only after the old candidate's rejection.
