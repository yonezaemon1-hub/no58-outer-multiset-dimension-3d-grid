# No.58 v0.3 — Audit A: independent review of the empty-layer compression lemma

**Date:** 2026-11-07  
**Status:** **COMPRESSION PASS / FINITE EXHAUSTIVENESS PASS** (separately implemented), **NO PUBLICATION AUTHORIZATION**.  
**Subject:** The claimed lower bound for the outer multiset dimension of `P_2 □ P_3 □ P_n`.

## Scope and verdict

| Item | Verdict | Basis |
| --- | --- | --- |
| Source ZIP members / source-log SHA256 | PASS | 13 ZIP entries byte-identical to mounted files; 12 SHA256 entries validated |
| One-layer deletion and lifting | PASS | Exact algebra for all three positional cases, with boundary conditions checked |
| Number of graph corners | PASS | Removing an interior unoccupied layer preserves both z-end faces and all corner membership |
| Cutoff `n <= 35` | PASS | At most 3 occupied z-layers and 4 empty runs, each reduced to at most 8 layers |
| Finite exhaustion for `n=2..35` | PASS | New C++17 implementation using distance-pair bitsets and **no local-square shortcut** |
| Local-square sign-mask shortcut | PASS for soundness | Algebra on two orthogonal unit edges; unnecessary in independent finite run |
| Symbolic 336/64-type classification | NOT AUDITED HERE | Audit B |
| Infinite collision identities for all normal forms | NOT AUDITED HERE | Audit C |
| Four-point upper bound | NOT AUDITED HERE | Audit D |
| Literature / novelty | INCONCLUSIVE | Separate review required |

This is an **independently written verification implementation in this working session**, not a peer-reviewed or externally commissioned third-party mathematical audit. Do not misreport it as an independent Claude audit.

## Setup

Let `n >= 2`. Vertices are `p=(x,y,z)` with `x∈{0,1}`, `y∈{0,1,2}`, `z∈{0,...,n-1}`; distances are Manhattan distances. A three-site set `S` is a subset of vertices. We only consider `S` with fewer than two *graph corners*, where a corner has `y∈{0,2}`, `z∈{0,n-1}`.

A **short ordered-distance collision** is a distinct pair of vertices `u,v` at graph distance 2 or 4 for which `d(u,s)=d(v,s)` for all `s∈S`. Such a collision cannot involve a vertex of `S`: otherwise one of the ordered distances would be zero for exactly one of the two vertices. Hence this is also a valid outer-multiset collision.

## Proof of the empty-layer compression/lifting lemma

Let nine consecutive layers `k-4,...,k+4` contain no site, with `4 <= k <= n-5`. Delete original layer `k` and shift every original vertex above it down by one. In the shorter grid, the image of an original site `s=(a,b,c)` is `s'=(a,b,c-1_{c>k})`, since `c≠k`.

Assume the shorter grid has a short ordered-distance collision `u',v'`. We exhibit a pair `u,v` in the original grid with unchanged graph distance, and show that for each original site `s`, the **difference** `d(u,s)-d(v,s)` equals `d(u',s')-d(v',s')`.

- **Both below the cut:** `z(u'),z(v') < k`. Lift both without shifting. Original sites below the cut have unchanged distances; sites above are one layer farther from both endpoints, adding `+1` to both distances. Every distance difference is preserved.
- **Both on/above the cut:** `z(u'),z(v') >= k`. Lift both by shifting `z` up by one. Sites above the deleted layer shift with the endpoints, giving no change; sites below become one layer farther from both endpoints, adding `+1` to both distances. Every distance difference is preserved.
- **Opposite sides of the cut:** assume `z(u') < k <= z(v')` after exchanging names if necessary. Since the graph distance is at most four, `z(u') >= k-4` and `z(v') <= k+3`. Lift **both unchanged**. Every original site lies either in a layer `<=k-5` or `>=k+5`. For left-side sites, original and short distances to both endpoints are identical. For right-side sites, original distances are `+1` relative to shorter-grid distances for **both** endpoints. Every difference is preserved. The lifted endpoints are valid distinct vertices, and their graph distance is unchanged.

Thus **every** short ordered-distance collision in the shorter graph lifts to one in the original graph. In particular, if the original graph had no such collision, the shorter graph cannot have one either.

The removed `k` is strictly interior, and no site occupies that layer. Its deletion preserves both terminal layers and the corner status of every site. It also preserves distinctness of all three sites.

## Why the cutoff is 35

The three sites occupy at most three distinct z-layers. Those layers split the remaining unoccupied layers into **at most four runs** (before, between, and after occupied layers). If some run has nine or more layers, its center layer can be deleted as above. Repeating strictly decreases `n` without changing the number of corner sites or creating short ordered-distance collisions when none existed. In a fully reduced configuration, each of the at most four empty runs has length at most eight; hence

`n <= 3 + 4*8 = 35`.

For contradiction, any hypothetical set of fewer than two corners with no short collision at some `n>35` therefore yields such a configuration at `n<=35`. Exhausting all `n=2..35` is sufficient.

## Independent finite certificate

Code: `No58_A_independent_pair_bitset.cpp`. This implementation **never calls the original `local_obstruct` predicate** and does not use its mask or breakpoint code.

For each `n`, it enumerates all unordered pairs `u,v` with Manhattan distance **exactly 2 or 4**. For every possible landmark `s`, it stores a bitset of pair indices satisfying `d(u,s)=d(v,s)`. For every triple `a<b<c` with fewer than two corners, it checks whether `bitset[a] & bitset[b] & bitset[c]` is nonempty. If empty, it exits nonzero and prints a concrete failing triple.

Compilation used `g++ -std=c++17 -O3 -Wall -Wextra -Werror -pedantic`. Actual result:

- **All `n=2,...,35`: PASS**.
- **13,921,300** three-site sets with fewer than two corners were checked, **zero failures**.
- At `n=35`, 1,515,808 sets were checked against 2,050 short vertex-pairs.

The final count matches the original certificate, although its witness search algorithm is different. The run log is `No58_A_independent_pair_bitset_LOG.txt`.

### Independent lifting stress test

Supplemental test `No58_A_lifting_stress.py` checked the equality of the entire ordered **distance-difference vector** for every short pair at distance 2 or 4, in 24 input-site configurations around eight deletion positions, with no sites in the protected nine-layer interval. This directly exercises all three branches without assuming the pair already collides:

- Both below: **35,250** exact difference identities checked.
- Both above: **32,646**.
- Straddling: **2,880**.
- Total: **70,776**, all PASS.

This test is corroborating evidence; the unrestricted argument is the algebraic lifting proof above, not the finite stress run.

## Limitation and handoff

Audit A proves the **specific lemma** that every three-site set with fewer than two graph corners has an ordered-distance collision at distance 2 or 4, for **all** `n>=2`. It does **not** by itself prove that every three-site set fails, because three-site sets containing two or three corners remain for Audit B (classification) and C (collision witnesses). The four-site upper bound and priority/novelty are also outside this audit.

**Global theorem: HOLD. Novelty: INCONCLUSIVE. GitHub/Zenodo: DO NOT PUBLISH.**
