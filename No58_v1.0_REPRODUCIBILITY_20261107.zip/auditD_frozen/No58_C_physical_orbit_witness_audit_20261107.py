#!/usr/bin/env python3
"""No58 Audit C: independently apply the eight witness families and their
coordinate reflections to every 3-site set with >=2 graph corners that
passes the local-square test, for all N=5..60. Pure standard-library Python.

This is a finite cross-check of Audit B's symbolic classification, NOT the
reason the symbolic proof is valid for arbitrary N.
"""
from itertools import combinations, product
from collections import Counter


def d(a,b):return sum(abs(x-y) for x,y in zip(a,b))
def sig(v,S):return sorted(d(v,s) for s in S)
def norm(S):return tuple(sorted(S))

def reflect(v,N,flip):
    x,y,z=v; bx,by,bz=flip
    return (1-x if bx else x, 2-y if by else y, N-z if bz else z)

def local_clear(S,N):
    def cut(ax,level):
        bits=sum(1<<j for j,s in enumerate(S) if s[ax]>=level)
        return min(bits,bits^7)
    x=cut(0,1); yy={cut(1,1),cut(1,2)}
    if x in yy:return False
    zz={cut(2,k) for k in range(1,N+1)}
    return not bool(zz.intersection({x,*yy}))

def A(N,t):
    S=((0,0,0),(0,0,N),(0,2,t))
    if t==0: return S,((0,2,1),(1,0,0))
    if t==N: return S,((0,2,N-1),(1,0,N))
    if not t%2:
        k=t//2;return S,((0,0,k),(0,1,k+1))
    if N%2:
        h=(N+t)//2;return S,((0,0,h),(0,1,h-1))
    m=N//2
    if t<m:return S,((0,1,m+1),(1,0,m-1))
    if t>m:return S,((0,1,m-1),(1,0,m+1))
    return S,((0,0,m-1),(0,0,m+1))

def B(N,t):
    S=((0,0,0),(0,0,N),(1,0,t))
    if N%2==0:
        m=N//2
        if t<m:return S,((0,1,m-1),(1,0,m+1))
        if t>m:return S,((0,1,m+1),(1,0,m-1))
        return S,((0,0,m-1),(0,0,m+1))
    if t==1:return S,((0,1,0),(1,1,1))
    if t%2:
        k=(t-1)//2;return S,((0,0,k),(1,0,k+1))
    if t==N-1:return S,((0,1,N),(1,1,N-1))
    h=(N+t+1)//2;return S,((0,0,h),(1,0,h-1))

def C(N,t):
    S=((0,0,0),(1,2,0),(0,2,t))
    if t==0:return S,((0,2,1),(1,0,0))
    if not t%2:
        k=t//2;return S,((0,0,k),(0,1,k+1))
    k=(t-1)//2;return S,((0,0,k+1),(1,0,k))

def E(N):
    m=N//2
    return [
        (((0,0,0),(0,1,N),(0,2,0)),((1,0,0),(1,2,0))),
        (((0,0,0),(0,1,N),(1,0,N)),((0,1,0),(1,0,0))),
        (((0,0,0),(0,2,0),(1,0,0)),((1,2,0),(0,0,1))),
        (((0,0,0),(0,2,0),(1,1,0)),((1,0,0),(1,2,0))),
        (((0,0,0),(0,2,N),(1,0,N)),((0,0,m),(1,0,m+1)) if N%2 else ((0,0,m),(0,1,m+1)))
    ]

def good_witness(S,u,v,N):
    vertices_ok=all(0<=x<2 and 0<=y<3 and 0<=z<=N for x,y,z in (u,v))
    return vertices_ok and u!=v and u not in S and v not in S and sig(u,S)==sig(v,S)

def run(N):
    # Construct witnesses by reflecting each of the three parametric families
    # and each of the five exceptional patterns.
    witness_map={}
    for template in [A(N,t) for t in range(N+1)]+[B(N,t) for t in range(N+1)]+[C(N,t) for t in range(N+1)]+E(N):
        S,(u,v)=template
        for flip in product((0,1),repeat=3):
            S1=norm(reflect(s,N,flip) for s in S)
            u1=reflect(u,N,flip);v1=reflect(v,N,flip)
            if not good_witness(S1,u1,v1,N):
                raise AssertionError(('invalid template',N,S1,u1,v1))
            witness_map[S1]=(u1,v1)
    corners=list(product(range(2),(0,2),(0,N)))
    corner_set=set(corners)
    others=[v for v in product(range(2),range(3),range(N+1)) if v not in corner_set]
    raw={norm((a,b,c)) for a,b in combinations(corners,2) for c in others}
    raw.update(norm(q) for q in combinations(corners,3))
    allowed={S for S in raw if local_clear(S,N)}
    if allowed!=witness_map.keys():
        raise AssertionError(('coverage mismatch',N,len(allowed),len(witness_map),list(allowed-witness_map.keys())[:2],list(witness_map.keys()-allowed)[:2]))
    expected=16*(N+1)+16
    if len(allowed)!=expected:raise AssertionError(('count mismatch',N,len(allowed),expected))
    for S in allowed:
        u,v=witness_map[S]
        if not good_witness(S,u,v,N):raise AssertionError(('bad mapped witness',N,S,u,v))
    return len(raw),len(allowed)

if __name__=='__main__':
    raw_total=good_total=0
    for N in range(5,61):
        raw,good=run(N)
        raw_total+=raw;good_total+=good
        if N in [5,6,7,8,10,20,40,60]:
            print(f'PASS n={N+1}: all >=2-corner triples={raw}, surviving local square={good}, witnessed={good}')
    print(f'PASS 56 grid lengths: {raw_total} full triples, {good_total} surviving triples all mapped to valid 2-vertex outer collisions')
    print('GENERAL all-n identity relies on separately verified affine case proof and Audit B ordinal classification.')
