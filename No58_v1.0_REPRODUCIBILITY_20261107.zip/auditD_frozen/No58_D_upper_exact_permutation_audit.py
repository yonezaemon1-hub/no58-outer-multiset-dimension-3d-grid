#!/usr/bin/env python3
"""Independent exact rational 4! matching audit for No.58 upper bound.

Uses no logic from the previous score/candidate-h script.
All 4! permutations of the four ordered distances, all 3x3 absolute-value chambers,
all 21 horizontal-cell pairs, and both parity families are tested.
Exact rational Gaussian elimination + Fourier-Motzkin (real feasibility) + exact parity check.
"""
from itertools import product, permutations
from collections import Counter
from fractions import Fraction as F
from functools import reduce
from math import gcd, lcm

def require(ok, msg):
    if not ok: raise RuntimeError('FAIL: ' + str(msg))

H=tuple(product(range(2), range(3)))
PERMS=tuple(permutations(range(4)))

def expr(h, side, first, t, n_min):
    x,y=h; a=x+y;b=1-x+y
    var=(0,1,0,0) if first else (0,0,1,0)  # [k,z,w,constant]
    nn=(2,0,0,n_min)
    def add(*parts):return tuple(map(sum,zip(*parts)))
    def sc(v,p):return tuple(e*p for e in v)
    u=(0,0,0,1)
    return [add(sc(u,a),var),
            add(sc(u,a),sc(u,1 if side==0 else -1),sc(var,-1 if side==0 else 1)),
            add(sc(u,a),nn,sc(var,-1)),
            add(sc(u,b),sc(u,t if side!=2 else -t),sc(var,-1 if side!=2 else 1))]

def inequalities(h_eq, a_side, b_side, t, n_min):
    # linear triples (a_k,a_z,a_w) <= rhs, in k=(N-n_min)/2
    a=[(-1,0,0,0),(-2,1,0,n_min),(-2,0,1,n_min)]
    for side, v in ((a_side,(0,1,0)),(b_side,(0,0,1))):
        nv=tuple(-e for e in v)
        if side==0:a.extend([(v[0],v[1],v[2],0),(*nv,0)])
        elif side==1:a.extend([(*nv,-1),(*v,t)])
        else:a.append((*nv,-t-1))
    if h_eq: a.append((0,1,-1,-1))  # w >= z + 1
    return a

def rref(rows):
    a=[[F(e) for e in row] for row in rows]; nr=len(a)
    piv=[]; r=0
    for c in range(3):
        pivot=next((i for i in range(r,nr) if a[i][c]),None)
        if pivot is None:continue
        a[r],a[pivot]=a[pivot],a[r]
        d=a[r][c];a[r]=[v/d for v in a[r]]
        for i in range(nr):
            if i==r or a[i][c]==0:continue
            factor=a[i][c]
            a[i]=[v-factor*w for v,w in zip(a[i],a[r])]
        piv.append(c);r+=1
    bad=any(not any(row[:3]) and row[3]!=0 for row in a)
    return bad, a, piv

def primitive(coeffs, rhs):
    fs=tuple(F(x) for x in (*coeffs,rhs))
    m=lcm(*(v.denominator for v in fs))
    ints=tuple(int(v*m) for v in fs)
    d=reduce(gcd,(abs(x) for x in ints),0) or 1
    return tuple(x//d for x in ints)

def simplify(cs, dim):
    # An inequality coeff_i*y_i <= rhs. Merge identical LHS with strongest RHS.
    dedup={}
    for c in cs:
        c=primitive(c[:dim],c[dim]); lhs=c[:dim];rhs=c[dim]
        if not any(lhs):
            if rhs<0:return None
            continue
        if lhs not in dedup or rhs<dedup[lhs]:dedup[lhs]=rhs
    return [(*k,v) for k,v in dedup.items()]

def eliminate(cs,dim):
    cs=simplify(cs,dim)
    if cs is None:return False
    while dim:
        idx=dim-1
        zero=[];pos=[];neg=[]
        for row in cs:
            a=row[idx]
            if a==0:zero.append((*row[:idx],row[-1]))
            elif a>0:pos.append(row)
            else:neg.append(row)
        for p in pos:
            for n in neg:
                # (-n[idx])*p + p[idx]*n eliminates y_idx
                zp=-n[idx]; zn=p[idx]
                new=tuple(zp*p[j]+zn*n[j] for j in range(idx))+(zp*p[-1]+zn*n[-1],)
                zero.append(new)
        dim-=1
        cs=simplify(zero,dim)
        if cs is None:return False
    return True

def exact_feasible(a_rows, b_rows, status):
    bad,r,piv=rref(a_rows)
    if bad:
        status['eq_contradiction']+=1
        return False,None
    free=[j for j in range(3) if j not in piv]
    # x_j = const + sum coef_free * y_free
    aff=[]
    for j in range(3):
        if j in free:
            aff.append((F(0),)*(1+free.index(j))+(F(1),)+ (F(0),)*(len(free)-free.index(j)-1))
        else:
            row=r[piv.index(j)]
            aff.append((row[3],)+tuple(-row[q] for q in free))
    reduced=[]
    for row in b_rows:
        coeff=[sum(F(row[j])*aff[j][i+1] for j in range(3)) for i in range(len(free))]
        rhs=F(row[-1])-sum(F(row[j])*aff[j][0] for j in range(3))
        reduced.append((*coeff,rhs))
    if not eliminate(reduced,len(free)):
        status['real_infeasible']+=1
        return False,None
    status['real_feasible']+=1
    return True,(aff,free)

def main():
 for t,n_min in ((2,6),(5,9)):
    status=Counter();remaining=[]
    for i,h1 in enumerate(H):
     for j,h2 in enumerate(H[i:],i):
      for side1,side2 in product(range(3),repeat=2):
       d1=expr(h1,side1,True,t,n_min)
       d2=expr(h2,side2,False,t,n_min)
       bounds=inequalities(i==j,side1,side2,t,n_min)
       for perm in PERMS:
        status['total']+=1
        eq=[[d1[ii][k]-d2[perm[ii]][k] for k in range(3)]+[d2[perm[ii]][-1]-d1[ii][-1]] for ii in range(4)]
        feasible, detail=exact_feasible(eq,bounds,status)
        if feasible:
            aff,free=detail
            remaining.append(dict(h1=h1,h2=h2,regions=(side1,side2),perm=perm,free=free,
                                  k=aff[0],z=aff[1],w=aff[2]))
    require(status['total']==4536,'incorrect total')
    print('Exact rational feasibility:',t,n_min,dict(status))
    for r in remaining:print('REMAINING_REAL_CASE',r)
    # Each remaining real solution must violate integrality: its coordinates are
    # affine functions of a freely-chosen integer coordinate, but at least one
    # other coordinate has a strictly half-integral intercept.
    for r in remaining:
        require(all(j in (0,1,2) for j in r['free']), r)
        require(any(aff[0].denominator==2 and all(c.denominator==1 for c in aff[1:])
                    for aff in [r['k'],r['z'],r['w']]), r)
    require(status['real_feasible']==(6 if t==2 else 3), status)
    print('PASS: surviving REAL cases imply half-integer lattice k for integer free variable')
 print('PASS: no possible collision for integer k,z,w, i.e. all eligible parity-restricted n')

if __name__=='__main__':main()
