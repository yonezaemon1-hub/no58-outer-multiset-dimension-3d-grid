# No.58 — Audit C: collision witnesses and reflection closure

**Date:** 2026-11-07 (JST)  
**Author of research:** Ryutaro Yonezu — Independent Researcher  
**Audit scope:** the eight normal forms of the 3-landmark, ≥2-corner case in `G_n=P_2 □ P_3 □ P_n`; full theorem, upper bound, novelty, third-party audit **not** in scope.  
**Result:** **COLLISION WITNESSES: PASS (this-session independent algebraic checks)**; overall proof/publication remains **HOLD**.

## 1. Exact claim checked

Let `N=n-1>=5`, `d(u,s)=|u_x-s_x|+|u_y-s_y|+|u_z-s_z|`, and `S` be a 3-element landmark set. An **outer-multiset collision witness** for `S` is a pair `u != v`, `u,v ∉ S`, such that the three distances to `S`, regarded as an unordered multiset with multiplicity, agree.

Audit B's conditional classification supplies the following normal forms under the eight coordinate reflections `(x,y,z) ↦ (1-x,y,z)`, `(x,y,z) ↦ (x,2-y,z)`, and `(x,y,z) ↦ (x,y,N-z)`:

- `A(t)={(0,0,0),(0,0,N),(0,2,t)}`
- `B(t)={(0,0,0),(0,0,N),(1,0,t)}`
- `C(t)={(0,0,0),(1,2,0),(0,2,t)}`
- `E0={(0,0,0),(0,1,N),(0,2,0)}`
- `E1={(0,0,0),(0,1,N),(1,0,N)}`
- `E2={(0,0,0),(0,2,0),(1,0,0)}`
- `E3={(0,0,0),(0,2,0),(1,1,0)}`
- `E4={(0,0,0),(0,2,N),(1,0,N)}`

The v0.3 proof candidate supplies explicit witness pairs for all branches in `A(t)`, `B(t)`, `C(t)` (each `0<=t<=N`) and `E0..E4`.

## 2. General-n symbolic verification (not a finite extrapolation)

Two independently implemented affine-arithmetic checkers were run:

1. `No58_C_affine_identity_stdlib_20261107.py`: **Python standard library only**. Represents affine functions as integer coefficient quadruples `(constant, p, q, r)` for independent nonnegative integer slack variables `p,q,r`. Every occurrence of `|affine|` must have coefficientwise nonnegative or nonpositive sign, or execution fails. It proves both witness coordinates lie in the graph, the endpoints are different and outside `S`, all three landmarks are distinct, and the exact unordered distance multisets are equal. All guards are explicit exceptions, even under `python -OO`.
2. `No58_C_affine_identity_audit_20261107.py`: separate SymPy-based verifier using polynomial coefficient tests for the same conditions; **optional**, not required for local verification.

The complete piecewise proof comprises **23 branches**, all PASS:

| Normal form | Branch partition | Number |
|---|---|---:|
| A | `t=0`; `t=N`; positive even interior `t`; odd interior `t` with odd `N`; odd `t` with even `N` separated by `t<m`, `t=m`, `t>m` (`N=2m`) | 7 |
| B | even `N`: `t<m`, `t=m`, `t>m`; odd `N`: `t=1`, odd `t>=3`, `t=N-1`, remaining even `t` | 7 |
| C | `t=0`; positive even `t`; odd `t` | 3 |
| E | `E0..E3`; `E4` with odd/even `N` separately | 6 |
| **Total** | | **23** |

For clarity, the symbolic cases use parametrizations such as:

- `A` positive even `t`: `k=1+p`, `t=2k`, `N=t+1+q`, `p,q>=0`.
- `A` odd `N`, odd interior `t`: `k=p`, `m=k+1+q`, `N=2m+1`, `t=2k+1`.
- Even `N=2m` with `m<t<N`: `m=2+p+q`, `t=m+1+p` (since `p=t-m-1>=0` and `q=2m-t-1>=0`).
- Odd `N=2m+1`, even `t<N-1`: `k=p`, `m=k+1+q`, `t=2k`.

These domains cover the respective branches for **every** `N>=5` and `0<=t<=N`. Some checker domains are strictly *larger* than the intended branches (e.g. omit an unnecessary parity restriction). This only strengthens the identity checks. Each branch is established by coefficientwise inequalities and exact multiset equality for free, nonnegative integer parameters; no bound on `N` is used.

**Example (family A, even interior `t=2k`, `1<=k`, `2k<N`):**

`u=(0,0,k)`, `v=(0,1,k+1)`, and both have the multiset `{k, k+2, N-k}`. The checker proves that neither `u` nor `v` belongs to `S`, including all parameter boundary cases.

## 3. Coverage of Audit B's 64 ordinal types and physical witnesses

`No58_C_physical_orbit_witness_audit_20261107.py` uses a separate arithmetic implementation to regenerate the original piecewise witnesses and reflect them. For every `N=5..60`, it enumerates every 3-subset with ≥2 corners, computes the local-square obstruction condition, and checks **set equality** between the surviving configurations and the reflected witness templates. For every surviving set, an explicit, physically valid outside collision is rechecked via direct Manhattan distances.

- **56** graph lengths `n=6..61`.
- **305,760** complete ≥2-corner 3-point configurations checked.
- **30,912** configurations survive local-square obstruction; **30,912/30,912** receive valid collision pairs.
- For every `n`, number surviving = `16n+16`, agreeing with Audit B's symbolic count.
- The finite scan independently checks the practical mapping of the normal forms; the **all-n** part of the claim relies on the already audited symbolic ordinal classification and the 23 exact branch identities, **not** on extrapolation from `n<=61`.

## 4. Adversarial / fail-closed tests

`No58_C_MUTATION_TEST_20261107.py` changes a witness coordinate to break the multiset equality; the standard-library affine checker and physical checker both reject it with nonzero failure conditions. Both executed under `python -I -OO` with no assertions silently stripped. Source files were not altered by the mutation test.

## 5. Scope and outstanding items

- **Audit A (compression, n≤35 finite reduction):** prior internal audit reported PASS; not re-audited here.
- **Audit B (336 ordinal types → 64 normal forms):** prior internal audit reported PASS; finite physical mapping also cross-checked here.
- **Audit C (outside collision witnesses for all normal forms and parameters): PASS** under two exact affine implementations plus physical reflection cross-check.
- **Audit D (four-point upper bound, entire theorem assembly, original v0.3 manifest/integrity, independent-source review): PENDING.**
- **EXTERNAL NOVELTY: INCONCLUSIVE. Third-party AI audit: NOT DONE. Human peer review: NOT DONE. RELEASE: HOLD.**

This is an independent *implementation* audit produced within this ChatGPT session; it is **not** an audit by a separate laboratory, model, or human referee.

## 6. Reproduction (free, Windows-compatible)

In the extracted folder with Python 3.10+:

```powershell
python -I -OO .\No58_C_affine_identity_stdlib_20261107.py
python -I -OO .\No58_C_physical_orbit_witness_audit_20261107.py
python -I -OO .\No58_C_MUTATION_TEST_20261107.py
```

The optional SymPy checker is not necessary for reproduction. All success paths print `PASS`; exceptions imply failure and a nonzero exit code. Preserve and independently verify `SHA256SUMS.txt` before trusting the results.
