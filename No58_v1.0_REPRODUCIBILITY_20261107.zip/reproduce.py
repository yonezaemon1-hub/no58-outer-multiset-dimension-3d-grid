#!/usr/bin/env python3
"""No.58 v1.0 publication runner. Frozen proof programs are never edited.

Python 3.10+ standard library and a C++17 compiler are required. Assertions in
the frozen programs are part of the certificate: never run Python with -O.
"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def verify_manifest():
    count = 0
    for line in (ROOT / "SHA256SUMS_REPRO.txt").read_text().splitlines():
        digest, name = line.split("  ", 1)
        path = (ROOT / name).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file():
            raise RuntimeError("Invalid or missing manifest entry: " + name)
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise RuntimeError("SHA256 mismatch: " + name)
        count += 1
    expected = {line.split("  ", 1)[1] for line in (ROOT / "SHA256SUMS_REPRO.txt").read_text().splitlines()}
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file() and p.name != "SHA256SUMS_REPRO.txt"}
    if actual != expected:
        raise RuntimeError("File inventory differs from manifest")
    print("PASS: release manifest and exact file inventory:", count)


def run():
    if sys.flags.optimize:
        raise SystemExit("FAIL-CLOSED: Python optimization disables frozen assertions")
    verify_manifest()
    compiler = shutil.which("g++") or shutil.which("clang++")
    if not compiler:
        raise SystemExit("C++17 compiler required: g++ or clang++")
    with tempfile.TemporaryDirectory(prefix="no58_reproduction_") as temp:
        work = Path(temp)
        executable = work / ("no58_lower.exe" if sys.platform == "win32" else "no58_lower")
        subprocess.run([compiler, "-std=c++17", "-O3", "-Wall", "-Wextra", "-Werror", "-pedantic", str(ROOT / "frozen_v03/No58_lower_corner_lemma_v03.cpp"), "-o", str(executable)], check=True, capture_output=True, text=True)
        jobs = [("finite lower bound", [str(executable)])]
        scripts = [
            "frozen_v03/No58_lower_symbolic_classification_v03.py",
            "frozen_v03/No58_upper_symbolic_proof_v01.py",
            "v05/No58_v05_finite_difference_witness_certificate.py",
            "v05/No58_v05_branch_coverage_audit.py",
            "auditD_frozen/No58_D_upper_exact_permutation_audit.py",
        ]
        jobs += [(name, [sys.executable, "-B", str(ROOT / name)]) for name in scripts]
        for label, command in jobs:
            result = subprocess.run(command, cwd=work, capture_output=True, text=True)
            if result.returncode:
                print(result.stdout)
                print(result.stderr)
                raise SystemExit("FAIL: " + label)
            print("PASS:", label)
        print("PASS: all six unchanged mathematical verifiers")
        print("Finite computation must be read with the manuscript's all-parameter reductions.")
        print("This execution is not independent human peer review or a novelty determination.")


if __name__ == "__main__":
    run()
