# No.58 v1.0: review and provenance boundaries

Release date: 2026-11-07. Author: Ryutaro Yonezu — Independent Researcher.

The user explicitly authorized the No.58 preprint publication, including the scope-limited claims below. Publication authorization changes release status; it does not turn partial reference verification or reviewer limitations into PASS.

| Item | Supported status and boundary |
|---|---|
| Result | odim(P₂ □ P₃ □ Pₙ)=4 for every integer n≥6, for the outer unordered-multiset definition only |
| Proof type | Computer-assisted; mathematical reductions plus finite exhaustive and exact symbolic computations |
| Latest external AI review | User-supplied publication instruction reports v0.5 MODEL / PROOF / COMPUTATION PASS; the transcript is not part of the supplied archive |
| Earlier external review | v0.4 overall PROOF PASS with a missing written ≤2-site argument and even-N B(N) certificate-coverage caveat; older collision-witness rederivation PARTIAL |
| Review limit | No claim of complete independent formalization, all-branch third-party rederivation, or human review |
| Internal A/B/C/D reports | Author-collaboration evidence, preserved unchanged and never presented as external AI reviews |
| Windows | User-supplied PowerShell 5.1 records: frozen v0.3/Audit D PASS; v0.5 24/24 branches and 268,528 configurations PASS |
| Release-preparation computation | Six main mathematical verifiers re-executed successfully, including full n=2,…,35 lower enumeration and exact upper permutation certificate |
| Novelty | INCONCLUSIVE; no directly identical theorem found in supplied screening, priority not established |
| References | PARTIAL; not an exhaustive theorem-by-theorem or citation-graph audit |
| Peer review | Not human peer-reviewed |
| Rights | All rights reserved |

The historical v0.5 STATUS and draft files were written before the latest review and Windows results; their bytes remain unchanged. The v1.0 manuscript and this note give the publication-time status without rewriting historical evidence.

## Bibliographic checks during publication preparation

Publisher and primary-source pages checked:

- Gil-Pons, Ramírez-Cruz, Trujillo-Rasua, Yero (2019), *Distance-based vertex identification in graphs: the outer multiset dimension*, Applied Mathematics and Computation 363, 124612. https://arxiv.org/abs/1902.03017
- Klavžar, Kuziak, Yero (2023; online 2022-12-31), *Further Contributions on the Outer Multiset Dimension of Graphs*, Results in Mathematics 78, Article 50. https://doi.org/10.1007/s00025-022-01829-8 . Author-hosted full version: https://users.fmf.uni-lj.si/klavzar/preprints/2207.06834.pdf . Theorem 5.1 covers two paths; concluding remarks ask about several-path products.
- Mora, Souto-Salorio, Tarrío-Tobar (2022), *Resolving sets tolerant to failures in three-dimensional grids*, Mediterranean Journal of Mathematics 19, Article 188. https://doi.org/10.1007/s00009-022-02096-1 . Ordered metric vectors and fault tolerance.
- Araujo-Pardo, Dalfó, Olsen, Reyes, Simanjuntak (2026-10-17), *On the outer multiset dimensions of graphs*, Boletín de la Sociedad Matemática Mexicana 32, Article 142. https://doi.org/10.1007/s40590-026-00973-3 . Publisher full article is available; the stated focus is cardinality/diameter bounds and circulants. No exhaustive exclusion of every possible implication is asserted.
- R. M. Marcelo, M. A. C. Tolentino, A. D. Garciano, J. C. Buot (2025), *On multiset dimension of cylindrical graphs*, Journal of Combinatorial Mathematics and Combinatorial Computing 126, 225–240. https://doi.org/10.61091/jcmcc126-15 . Publisher PDF supplies the four authors; ordinary multiset dimension on path × cycle products.

Supplied-audit references retained with a current access limitation:

- Farhan, Klavžar, Kuziak, Yero, *Multiset resolvability parameters in graphs: A survey with new results and open problems*, arXiv:2607.10311 (2026-07-11), Problem 10. https://arxiv.org/html/2607.10311 . The supplied prior-art audit identifies the problem and authors. Direct fetching during publication preparation failed. The reference and special-family motivation are attributed accordingly.
- B. Peng, *The Outer Multiset Dimension of Toroidal Grids*, arXiv:2609.20073 (2026-09-17). https://arxiv.org/abs/2609.20073 . Supplied-audit bibliography; current direct fetching failed. Two-cycle tori are a different family.

The mathematical proof does not require these unavailable full texts. Literature uncertainty remains explicit.
