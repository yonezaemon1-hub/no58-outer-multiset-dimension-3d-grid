#!/usr/bin/env python3
"""Fail-closed constructive coverage for the 24 branch parametrizations.

Mathematical coverage is a case split by parity, boundary, and comparison of
 t with m=floor(N/2). For every N>=5 and 0<=t<=N the formulas below give
 nonnegative p,q and a branch j. This finite test checks N=5..420, but
 the case split and symbolic inverses printed in the audit note are the
 all-N argument; the test is not substituted for that proof.
"""
from itertools import product
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import No58_v05_finite_difference_witness_certificate as cert

def require(ok, why):
    if not ok: raise RuntimeError('FAIL-CLOSED: '+str(why))

def target(fam,N,t):
    require(N>=5 and 0<=t<=N,'input outside domain')
    m=N//2
    if fam=='A':
        if t==0: return 1,N-5,0
        if t==N: return 2,N-5,0
        if t%2==0: return 3,t//2-1,N-t-1
        if N%2:
            k=(t-1)//2
            return 4,k,m-k-1
        if t<m: return 5,t-1,m-t-1
        if t>m:
            p=t-m-1
            return 6,p,m-2-p
        return 7,m-3,0
    if fam=='B':
        if N%2==0:
            if t==N: return 24,m-3,0
            if t<m: return 8,t,m-t-1
            if t>m:
                p=t-m-1
                return 9,p,m-2-p
            return 10,m-3,0
        if t==1: return 11,m-2,0
        if t%2:
            k=(t-1)//2
            return 12,k-1,m-k
        if t==N-1: return 13,m-2,0
        k=t//2
        return 14,k,m-k-1
    if fam=='C':
        if t==0: return 15,N-5,0
        if t%2==0: return 16,t//2-1,N-t
        return 17,(t-1)//2,N-t
    raise RuntimeError('unknown family')

def validate(fam,N,t):
    j,p,q=target(fam,N,t)
    require(p>=0 and q>=0,(fam,N,t,j,p,q))
    actual=cert.case(j,p,q)
    require(actual[0]==N and actual[1]==t,(fam,N,t,'wrong parameters',j,p,q,actual[:2]))
    expected={'A':cert.A,'B':cert.B,'C':cert.C}[fam](N,t)
    require(actual[2]==expected,(fam,N,t,'wrong site set'))
    # No normalization or hidden equivalence needed: branch handles this exact set.
    u,v=actual[3],actual[4]
    d=lambda a,b:sum(abs(a[k]-b[k]) for k in range(3))
    require(u!=v and u not in expected and v not in expected,(fam,N,t,'invalid exterior witness'))
    require(all(0<=w[0]<=1 and 0<=w[1]<=2 and 0<=w[2]<=N for w in (u,v)),(fam,N,t,'out-of-bounds witness'))
    require(sorted(d(u,s) for s in expected)==sorted(d(v,s) for s in expected),(fam,N,t,'distance collision not established'))
    return j

def main():
    counts={i:0 for i in range(1,25)}
    boundary=[]
    checks=0
    for N in range(5,421):
        for fam,t in product('ABC',range(N+1)):
            j=validate(fam,N,t)
            counts[j]+=1
            checks+=1
            if fam=='B' and N%2==0 and t==N: boundary.append(N)
        for e in range(5):
            j=(18+e) if e<4 else (22 if N%2 else 23)
            p=(N-5) if e<4 else ((N-1)//2-2 if N%2 else N//2-3)
            require(p>=0,(N,e,p))
            N2,_,S,u,v=cert.case(j,p,0)
            require(N2==N and S==cert.E(e,N),(N,e,'E mismatch'))
            d=lambda a,b:sum(abs(a[k]-b[k]) for k in range(3))
            require(u!=v and u not in S and v not in S, (N,e,'E invalid'))
            require(sorted(d(u,s) for s in S)==sorted(d(v,s) for s in S),(N,e,'E failure'))
            counts[j]+=1;checks+=1
    require(len(boundary)==len(range(6,421,2)), 'B even endpoint count')
    require(all(counts.values()),('uncovered certificate branch',counts))
    print('PASS: A/B/C all t=0..N, N=5..420 and E0..E4; checks =',checks)
    print('PASS: B(N) at even N explicit j=24, checked',len(boundary),'boundary instances')
    print('PASS: 24/24 branch parametrizations reached; no uncovered admissible (N,t)')
    print('Counts:', counts)
    print('GENERAL mathematical coverage: all-N parity/boundary case partition and nonnegative inverse slack formulas; finite scan corroborates but does not replace algebra.')
if __name__=='__main__': main()
