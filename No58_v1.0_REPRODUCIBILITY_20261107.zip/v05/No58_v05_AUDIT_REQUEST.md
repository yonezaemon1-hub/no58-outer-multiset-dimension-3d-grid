# No.58 v0.5 — separate adversarial difference audit (HOLD)

Please audit *only the v0.4->v0.5 delta first*, as a separate reviewer:

1. Re-derive Lemma 0's unit-cube sign-vector pigeonhole proof for |S|<=2, including the assertion that a collision endpoint cannot be in S. Look for exceptions at n=2.
2. Check even N=2m (m>=3), B(N) `S={(0,0,0),(0,0,N),(1,0,N)}` with u=(0,1,m+1), v=(1,0,m-1), distinct and exterior with equal unordered distance multisets. Verify case 24 actually covers all even N>=6 (not just N<=420).
3. Check independently that the A/B/C/E branch partition listed in v0.5 proof is exhaustive, and that all inverses yield nonnegative integers p,q. Do not infer all-N coverage only from the 268,528 finite tests.
4. Verify that the former 23 formulas and v0.3/Audit D frozen ZIP bytes have not changed. Confirm that REVIEW_ONLY and FULL_HOLD labels describe their exact content.
5. Recheck bibliographic claims from publishers, distinguish local outer from outer, and test whether any known theorem implies the exact 3-path result. Do not promote novelty beyond INCONCLUSIVE without proof.

Record MODEL, PROOF, COMPUTATION, INTEGRITY, REFERENCES, NOVELTY separately. Note differences in reviewer independence. Do not publish or change any online artifact. Human review remains undone.
