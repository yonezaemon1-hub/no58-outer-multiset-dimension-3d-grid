No.58 v0.5 REVIEW_ONLY. No publication authorized.
This lightweight archive contains only v0.5 repaired manuscript and supplemental verification (and its own manifest), **not** v0.3/v0.4/Audit D frozen originals.
For full provenance use No58_v05_FULL_HOLD_20261107.zip, which includes the byte-identical No58_v04_AUDIT_HOLD_20261107.zip; that earlier full archive contains frozen v0.3 and Audit D files.
The SHA256 manifest covers files in THIS archive, excluding the manifest itself.
Do not distribute private raw Windows logs. NOVELTY INCONCLUSIVE; HUMAN PEER REVIEW NOT DONE; RELEASE HOLD.
