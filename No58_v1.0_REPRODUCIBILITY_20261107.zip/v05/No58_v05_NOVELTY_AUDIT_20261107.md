# No.58 v0.5 — Prior-art and novelty audit (2026-11-07)

**Author/project:** Ryutaro Yonezu, Independent Researcher — No.58 (3D grid)

**Candidate theorem:** For all integers n >= 6, odim(P_2 □ P_3 □ P_n) = 4, where odim is the *outer multiset dimension* (the distance multisets distinguish vertices outside the landmark set).

**Decision:** **DIRECT DUPLICATE NOT FOUND in searched sources; NOVELTY INCONCLUSIVE; REFERENCES PARTIAL; RELEASE HOLD.** This is a literature-screening result, **not** proof of first discovery, priority, or a mathematical verification certificate. Mathematical and Windows reproducibility audits are recorded separately.

## Source-by-source claim boundary

| Source | Publication/date | Established scope | Does it imply the No.58 exact value? |
|---|---|---|---|
| Gil-Pons, Ramírez-Cruz, Trujillo-Rasua, Yero, *Distance-based vertex identification in graphs: the outer multiset dimension* | Applied Mathematics and Computation 363 (2019), 124612; https://arxiv.org/abs/1902.03017 | Defines/studies the outer multiset parameter and general complexity/results | **No same three-factor grid formula located**; the concept is prior art |
| Klavžar, Kuziak, Yero, *Further Contributions on the Outer Multiset Dimension of Graphs* | Results in Mathematics 78:50 (2023; first online 2022-12-31), https://doi.org/10.1007/s00025-022-01829-8; author PDF https://users.fmf.uni-lj.si/klavzar/preprints/2207.06834.pdf | Theorem 5.1: odim(P_s □ P_t)=3 for s,t>=2. Concluding section proposes several-path Cartesian grids as further challenge | **No** — theorem has two path factors; the authors expressly identify the multidimensional extension as open |
| Mora, Souto-Salorio, Tarrío-Tobar, *Resolving sets tolerant to failures in three-dimensional grids* | Mediterr. J. Math. 19:188 (2022), https://doi.org/10.1007/s00009-022-02096-1 | Ordered distance-vector metric dimension / fault-tolerance | **Not by itself** — a bound for labelled distances does not determine the outer unordered multiset dimension |
| Farhan, Klavžar, Kuziak, Yero, *Multiset resolvability parameters in graphs: A survey with new results and open problems* | arXiv:2607.10311, 2026-07-11, https://arxiv.org/html/2607.10311 | Theorem 4.9 cites the two-path result; Problem 10 explicitly asks extension to products of more than two paths | **No** — explicitly presents broader extension as an open problem as of Jul 2026 |
| Albejani, Lin, Ryan, Sugeng, *A Survey on Multiset Dimension and Its Variations* | arXiv:2607.08128; journal 2026-09-25, https://doi.org/10.19139/soic-2310-5070-4062 | Surveys distinct multiset parameters and variants | No identical exact theorem located in searchable abstract/summary; **full independent theorem-by-theorem comparison incomplete** |
| Marcelo, Tolentino, Garciano, Buot, *On multiset dimension of cylindrical graphs* | J. Combin. Math. Combin. Comput. 126 (2025), https://combinatorialpress.com/jcmcc-articles/volume-126/on-multiset-dimension-of-cylindrical-graphs/ | Ordinary multiset dimension of P_m □ C_n (cylindrical grid) | **Not direct** — cycles rather than two short path factors, and ordinary (non-outer) parameter |
| Allikvere, *The Multiset Dimension of Graphs: Extremal Values and King Grids* | 2026-07-30, https://arxiv.org/abs/2607.28813 | Ordinary multiset dimension of strong products P_n ⊠ P_n, strips | **Not direct** — different graph product and identification rule |
| Peng, *The Outer Multiset Dimension of Toroidal Grids* | 2026-09-17, https://arxiv.org/abs/2609.20073 | odim(C_s □ C_t) of two cycle factors; values 3..8 | **Not direct** — toroidal two-factor cycles, not three path factors; proof techniques may be analogous |
| Araujo-Pardo, Dalfó, Olsen, Reyes, Simanjuntak, *On the outer multiset dimensions of graphs* | Bol. Soc. Mat. Mex. 32:142, 2026-10-17, https://doi.org/10.1007/s40590-026-00973-3 | General cardinality/diameter bounds and circulant C_n(1,2) family | **Not direct** — no formula for P_2 □ P_3 □ P_n found in accessible article text; a fully general corollary has not been categorically excluded |
| Pervaiz, Simanjuntak, Saputro, *Outer multiset dimensions of (extended) corona product graphs* | Electron. J. Graph Theory Appl. 14(2), online early Nov 2026, https://www.ejgta.org/index.php/ejgta/article/view/2492/0 | Corona and extended-corona product classes | **Not direct** — distinct graph operation |

## Other identifications and checks

- Internal research register for No.1–57 had already been compared in this conversation. No.43 addresses two-leaky forcing on prism graphs; No.44 addresses outer mutual visibility of discrete tori. **Neither is an outer multiset dimension theorem for this 3D Cartesian path family.** This is not a new byte-by-byte audit of all historical papers.
- Search strings included: `"outer multiset dimension" "P_2" "P_3" "P_n"`, `"outer multiset dimension" "three" "paths" Cartesian`, `"3-dimensional grid" "outer multiset resolving"`, `"outer multiset" "ladder" Cartesian`, `"multidimensional grids" "outer multiset"`, and near synonyms (mesh/rectangular prism/king grid).
- For the general inequalities, dim(G) <= odim(G) <= md(G); the known metric dimension 3 supplies only a lower bound 3. General counting and diameter bounds are not an exact four-landmark theorem on this family. The exact lower-bound obstruction and explicit four-landmark construction remain essential technical contributions *if accepted*.
- Important bibliographic boundary: `local outer multiset dimension`, `multiset partition dimension`, `edge multiset dimension`, `ordinary multiset dimension`, and ordered `metric dimension` are **not** the same invariant as `outer multiset dimension`.

## Residual priority/novelty risks

1. Newly posted/unindexed preprints or 2026 theses (including unpublished overlapping work) may already contain the three-factor case.
2. A theorem stated using alternate language for the same invariant or a broad Cartesian product theorem may imply the exact value indirectly.
3. Search indexing, citations and full texts for all post-July-2026 papers were not exhaustively traversed. A thorough citation graph / full-text scan remains outstanding.
4. Even if the result is new, the techniques of finite certificate, coordinate symmetry and distance collisions may be known; originality should be claimed for the **specific theorem and verified finite reduction** only, not for these methods generally.
5. No human peer review. Existing Claude review and Windows logs concern mathematical proof/reproducibility, not newness or priority.

## Decision and next action

- **Candidate status: RETAIN (promising partial answer to a specifically documented open problem).**
- **Mathematical audit: separately recorded.**
- **Novelty: INCONCLUSIVE (stronger evidence of a gap, not a novelty PASS).**
- **Publication: HOLD** until the researcher explicitly authorizes any release after reviewing remaining uncertainty.
- Next targeted check: exhaustively inspect citations to the 2023 Klavžar–Kuziak–Yero paper and the 2026 Farhan et al. survey, especially works posted July–Nov 2026, and search graduate repositories or non-arXiv preprints under equivalent product notation.
