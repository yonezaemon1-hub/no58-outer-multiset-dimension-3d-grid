# No.58 — focused prior-art comparison v0.5 (2026-11-07; **PARTIAL**)

| Source | Proven or investigated scope | Relationship with candidate |
|---|---|---|
| Gil-Pons et al. (2019), Applied Mathematics and Computation 363, Article 124612, https://arxiv.org/abs/1902.03017 | Definition and foundational properties of outer multiset dimension | Parameter is known; do not claim invention |
| Klavžar, Kuziak, Yero (2023), Results Math. 78:50, https://doi.org/10.1007/s00025-022-01829-8 | `odim(P_s □ P_t)=3` for `s,t≥2` | Only two paths. No direct equality for this three-path family seen in reviewed abstract |
| Mora, Souto-Salorio, Tarrío-Tobar (2022), Mediterr. J. Math. 19:188, https://doi.org/10.1007/s00009-022-02096-1 | Ordered metric resolving/fault-tolerant sets for 3D grids | Different identification parameter. Not a direct outer multiset theorem |
| Marcelo, Tolentino, Garciano, Buot (2025), J. Comb. Math. Comb. Comput. 126:225–240, DOI https://doi.org/10.61091/jcmcc126-15; publisher https://combinatorialpress.com/jcmcc-articles/volume-126/on-multiset-dimension-of-cylindrical-graphs/ | **Verified on publisher site:** ordinary multiset dimension for `P_m □ C_n` | Both graph type and strength of parameter differ; prior upper constructions must not be misclaimed |
| Farhan et al. (11 July 2026), arXiv:2607.10311, https://arxiv.org/html/2607.10311 | Survey, Problem 10: extending 2-path Cartesian result to >2 paths | Explicit motivation. Candidate addresses a special infinite family only |
| Peng (17 Sep 2026), arXiv:2609.20073, https://arxiv.org/abs/2609.20073 | Outer multiset dimension of `C_s □ C_t` | Different graph family: torus, 2D cycles |
| Araujo-Pardo, Dalfó, Olsen, Reyes, Simanjuntak (17 Oct 2026), Bol. Soc. Mat. Mex. 32:142, https://link.springer.com/article/10.1007/s40590-026-00973-3 | **Verified on publisher site:** general constructions, bounds, and circulant C_n(1,2); not a three-path formula | No identical theorem found in inspected online presentation; general-theorem corollaries not exhaustively eliminated |

**What is not yet checked:** full downstream citation graph of every source; unpublished preprints and thesis repositories; equivalent reformulations of product graphs; complete texts of potentially overlapping works; post-November-2026 publications. No claim of exhaustive search or novelty PASS.

**Current finding:** the candidate is consistent with being a narrow partial answer to Farhan et al.'s explicit Problem 10, but *NOVELTY remains INCONCLUSIVE*.

### Verification notes added in v0.5
- The 17 October 2026 Springer article's title, five named authors, volume 32/article 142, date, DOI, and abstract were verified on the official publisher page. This corrects the reviewer's unable-to-locate flag; it does **not** imply complete theorem-level overlap checking.
- The 23 May 2025 cylindrical paper and DOI were verified on Combinatorial Press; the publisher's typeset PDF metadata supplies the four author names. Its ordinary multiset dimension concerns `P_m □ C_n`, not the exact three-path outer problem. No inference from its upper bound is asserted as a novelty proof.
- arXiv:2507.15071 is *Local (Outer) Multiset Dimensions of Graphs* (Simanjuntak, Hasan, Anggarawan, July 2025), a **local** parameter (only adjacent vertex pairs); do not conflate it with standard outer multiset dimension of all pairs outside S.
- The July 2026 Farhan–Klavžar–Kuziak–Yero survey, Problem 10, explicitly requests extending the two-path Cartesian result to more paths. The present theorem would cover only `P_2 □ P_3 □ P_n` for n>=6, provided the proof is accepted.

**Open:** a full theorem-by-theorem citation chain, unpublished and alternate-nomenclature work, and whether a broader known result implies this particular exact formula. NOVELTY is still INCONCLUSIVE.
