# No.58 v0.5 — Corrected general-lower-bound candidate (coverage and citation repair)

**The main mathematical claim, all v0.3 constructions, and the v0.3/Audit D frozen code remain unchanged.** v0.5 adds an explicit two-landmark obstruction argument, repairs the B(N) even-N witness-certificate coverage, and clarifies archive provenance and bibliographic verification. Neither mathematics nor novelty is asserted to have received final third-party approval.

---

# No.58 v0.3 — General lower bound candidate for the outer multiset dimension of a 3D grid

Author: Ryutaro Yonezu — Independent Researcher  
Prepared: 2026-11-07  
Status: **v0.5 CORRECTED AUDIT CANDIDATE — INTERNAL COMPUTER-ASSISTED CHECKS PASS; SEPARATE AI REVIEW REPORTED PROOF PASS WITH COVERAGE/EDITORIAL CAVEATS; FULL THIRD-PARTY RE-DERIVATION INCOMPLETE; NOVELTY INCONCLUSIVE; RELEASE HOLD.**

## Claimed theorem (subject to independent audit)
For every integer `n >= 6`, writing `G_n = P_2 □ P_3 □ P_n`,

`odim(G_n) = 4`.

Here a subset `S` is *outer multiset resolving* if for any two distinct vertices `u,v` outside `S`, the unordered multisets of the distances from `u,v` to `S` are different. A three-site subset must fail; the four-site upper bound uses the separately provided upper certificate.

Coordinates are `(x,y,z)` with `x in {0,1}`, `y in {0,1,2}`, `z in {0,...,N}`, where `N=n-1`. Distance is Manhattan distance.

## Part I: lower bound, split on graph corners
A graph corner is `(x,y,z)` with `y in {0,2}` and `z in {0,N}`. There are 8 graph corners.

An outer multiset resolving set must also be an ordinary (ordered) resolving set. Indeed, if two distinct vertices have the same full ordered distance vectors, neither can belong to S (the coordinate corresponding to a member of S would be 0 at that vertex and positive at the other), so these are two vertices outside S with the same distance multisets. We prove directly that |S|<=2 never ordinarily resolves this grid. Hence to establish the lower bound four it remains to exclude |S|=3.

### Lemma 0 (one unit cube excludes at most two landmarks)
Choose any induced unit cube with coordinate edges in the x-, y-, and z-directions (it exists for every n>=2). For each landmark s, the increment in Manhattan distance along an oriented unit edge parallel to any chosen coordinate direction is +1 or -1 and is constant across the parallel edges of this cube. If |S|=2, record the increments in a sign column in {+1,-1}^2 for each of the three coordinate directions X,Y,Z. Modulo simultaneous negation, this space has only **two** sign classes. By the pigeonhole principle two directions, say X and Y, have equal or opposite columns. On the corresponding unit square, if X=Y, its (1,0) and (0,1) diagonal corners have identical ordered distance vectors; if X=-Y, its (0,0) and (1,1) diagonal corners have identical ordered distance vectors. The equality is coordinatewise for all landmarks. These corners are distinct and cannot belong to S because a landmark itself would have a zero distance coordinate where the other vertex has positive distance. The same argument applies to |S|=1 (pad the sign columns or use their one-coordinate form). For |S|=0, all vertices have the same empty multiset. Consequently **no S of cardinality at most two is outer multiset resolving**, for every n>=2. This proof is internal and does not depend on the 2022 3D metric-dimension citation.

### Lemma 1: every 3-site set with fewer than two corners fails ordinary resolving
Stronger: two vertices at graph distance exactly 2 or 4 have the same **ordered** three-component distance vector.

**Finite reduction, with complete lifting argument:** Consider any maximal interval of at least nine consecutive `z`-layers containing none of the three sites. Remove a layer `k` with at least four site-free layers on each side, and shift all layers above `k` down by one. Suppose that the shortened grid has an equal-ordered-distance pair `u',v'` with `d(u',v')<=4`.

* If both vertices are below `k`, lift them unchanged: for landmarks above `k` both distances increase by one, and all other distances remain unchanged.
* If both are on or above `k` in the shortened grid, lift both vertices up by one: for landmarks below `k` both distances increase by one, and all other distances remain unchanged.
* If they lie on opposite sides of the cut, their z-coordinates differ by at most four. Both z-coordinates therefore lie inside the same site-free run (because `k` has four empty layers to either side). Lift the two vertices with the **same** z-coordinates as in the shortened graph. Every landmark is strictly to one side or the other of both vertices, so the difference of their distances to each landmark remains unchanged.

In all three cases, a distinct pair of the same graph distance 2 or 4 and with identical ordered distance vectors lifts to the original graph. The number of corner landmarks is invariant under deletion of a site-free interior layer. Consequently a hypothetical counterexample (fewer than 2 corners; no short ordered collision) compresses to one with at most 35 layers: there are at most four runs of empty layers and at most three occupied layers; after repeated deletion every run has length at most eight, so `n <= 4*8 + 3 = 35`.

**Finite certificate:** `No58_lower_corner_lemma_v03.cpp` checks *every* triple with fewer than two corners for *every n=2,...,35*. It constructs the full Manhattan distance matrix. It first checks for local-square collisions, and otherwise compares the distance vectors for all vertex pairs at distance 2 or 4. The local-square shortcut is sound by the next paragraph. No triple survives.

**Local-square shortcut justification:** For a site `s_i`, crossing any unit edge at coordinate axis `j` and threshold `k` changes its distance to that site by `+1` or `-1` according to the side of `s_i`. Encode the three signs by a mask; identify a mask with its bitwise complement. If the sign masks of cuts along **two distinct coordinate directions** are equal up to complement, the corresponding unit square has a pair of opposite corners whose ordered three-distance vectors agree. These opposite corners have graph distance 2. The possible masks for all z-cuts only change at `z_i + 1`; hence checking the few breakpoints as the code does is exact. (There is no need to compare two cuts in the same direction.)

The C++ exhaustive certificate has no heuristic pruning and exhausts 13,921,300 triples with fewer than 2 corners across the 34 lengths. Of these, 13,864,044 have a square obstruction, and 57,256 are disposed of by direct distance-2-or-4 witnesses. Each rejected configuration has an actual short collision.

### Lemma 2: classification of the remaining triples via 336 symbolic types
Suppose a 3-site set has at least two corners. If there is a local-square obstruction it already fails. Otherwise fix the two corner sites. The third site has z-coordinate either `0`, `N`, or one intermediate coordinate `t`, `0<t<N`. Its x and y coordinates have only six possibilities.

For the unit-square obstruction, only the ordering `0 < t < N` matters, never the sizes of the gaps. Accordingly use the symbolic labels `0, I, N` and the x/y cuts together with the z-cuts between `0/I` and `I/N`. There are exactly 336 distinct 3-site ordinal types with at least 2 corners, *before* applying the unit-square obstruction test: `C(8,2) * 10 + C(8,3) = 336`. Of these, **64 types have no unit-square ordered-distance collision** and the remaining **272 types have such an obstruction**. The 64 survivors split into 16 types with exactly 2 corners and the third site's z-coordinate on a boundary layer, 16 types with exactly 2 corners and an interior symbolic layer `I`, and 32 types containing 3 corners. These are survivor counts, not the decomposition of all 336 raw types.

The checker `No58_lower_symbolic_classification_v03.py` enumerates the 336 types as finite sets, tests the exact unit-square condition (including complement masks) and compares the accepted set of 64 types with the closure under all eight coordinate reflections of the patterns below. Set equality is tested directly. Thus **for every `N>=5`**, every three-site configuration with at least two corners and without a square obstruction is, under an automorphism, one of the three families or five exceptions below.

Three parameterized families (`0<=t<=N`):

- `A(t) = {(0,0,0), (0,0,N), (0,2,t)}`
- `B(t) = {(0,0,0), (0,0,N), (1,0,t)}`
- `C(t) = {(0,0,0), (1,2,0), (0,2,t)}`

Five additional patterns:

- `E0 = {(0,0,0),(0,1,N),(0,2,0)}`
- `E1 = {(0,0,0),(0,1,N),(1,0,N)}`
- `E2 = {(0,0,0),(0,2,0),(1,0,0)}`
- `E3 = {(0,0,0),(0,2,0),(1,1,0)}`
- `E4 = {(0,0,0),(0,2,N),(1,0,N)}`

The exact accepted counts by location are `(2 corners, third at boundary)=16`, `(2 corners, third at interior t)=16 per t`, `(3 corners)=32`; hence the total is `16*(n-2)+16+32=16n+16`. This matches but does not assume previous finite metric-basis counts.

### Lemma 3: all eight normal forms fail outer multiset resolution
Below a witness `(u,v)` always consists of **two distinct vertices outside S**, with exactly the same unordered multiset of three distances to S. The identities hold for all `N>=5` with branch conditions given. They are checked by inserting the coordinates into `d((x,y,z),(a,b,c))=|x-a|+|y-b|+|z-c|` and simplifying the absolute values under the branch inequalities. The v0.5 arithmetic checker now certifies the 23 original parameter branches **plus one missing even-N endpoint (B(N))**. The separate coverage checker constructs nonnegative slack parameters for every family A/B/C and every `0<=t<=N` (see the v0.5 audit note). It was physically rechecked for N=5,...,420. The intended general proof is the branch partition and affine identities, not extrapolation from finite tests.

#### Family A
- `t=0`: `u=(0,2,1), v=(1,0,0)`; common distances `{1,3,N+1}`.
- `t=N`: `u=(0,2,N-1), v=(1,0,N)`; common distances `{1,3,N+1}`.
- `t=2k` with `1<=k` and `2k<N`: `u=(0,0,k), v=(0,1,k+1)`; common distances `{k,k+2,N-k}`.
- `N=2m+1`, `t=2k+1` with `0<=k<=m-1`: `h=m+k+1`; `u=(0,0,h),v=(0,1,h-1)`; common distances `{h,m-k,m-k+2}`.
- `N=2m`, `t` odd and `t<m`: `u=(0,1,m+1),v=(1,0,m-1)`; common distances `{m,m+2,m+2-t}`.
- `N=2m`, `t` odd and `t>m`: `u=(0,1,m-1),v=(1,0,m+1)`; common distances `{m,m+2,t-m+2}`.
- `N=2m`, `t=m` (necessarily odd in the residual branch): `u=(0,0,m-1),v=(0,0,m+1)`; common distances `{m-1,m+1,3}`.

#### Family B
- `N=2m`, `t<m`: `u=(0,1,m-1),v=(1,0,m+1)`; common distances `{m,m+2,m+1-t}`.
- `N=2m`, `t>m`: `u=(0,1,m+1),v=(1,0,m-1)`; common distances `{m,m+2,t-m+1}`.
  - **Boundary correction for the v0.5 certificate:** the formula above also holds for `t=N=2m`. The v0.4 parametrization of this branch covered only `m<t<=N-1`; v0.5 adds certificate branch **24** with `m=3+p`, `N=2m`, `t=N`. Its witness is `u=(0,1,m+1), v=(1,0,m-1)`, with common multiset `{m,m+2,m+1}`. Equivalently B(N) is the z-reflection of B(0), but this certificate uses a direct algebraic boundary branch.
- `N=2m`, `t=m`: `u=(0,0,m-1),v=(0,0,m+1)`; common distances `{m-1,m+1,2}`.
- `N=2m+1`, `t=1`: `u=(0,1,0),v=(1,1,1)`; common distances `{1,3,N+1}`.
- `N=2m+1`, `t=2k+1`, `k>=1`: `u=(0,0,k),v=(1,0,k+1)`; common distances `{k,k+2,N-k}`.
- `N=2m+1`, `t=N-1`: `u=(0,1,N),v=(1,1,N-1)`; common distances `{1,3,N+1}`.
- `N=2m+1`, `t=2k<N-1`: `h=m+k+1`; `u=(0,0,h),v=(1,0,h-1)`; common distances `{h,m-k,m-k+2}`.

#### Family C
- `t=0`: `u=(0,2,1),v=(1,0,0)`; common distances `{1,2,3}`.
- `t=2k>=2`: `u=(0,0,k),v=(0,1,k+1)`; common distances `{k,k+2,k+3}`.
- `t=2k+1`: `u=(0,0,k+1),v=(1,0,k)`; common distances `{k+1,k+2,k+4}`.

#### Five exceptional patterns
- `E0`: `u=(1,0,0),v=(1,2,0)`; common distances `{1,3,N+2}`.
- `E1`: `u=(0,1,0),v=(1,0,0)`; common distances `{1,N,N+2}`.
- `E2`: `u=(1,2,0),v=(0,0,1)`; common distances `{1,2,3}`.
- `E3`: `u=(1,0,0),v=(1,2,0)`; common distances `{1,1,3}`.
- `E4`, `N=2m+1`: `u=(0,0,m),v=(1,0,m+1)`; common distances `{m,m+2,m+3}`.
- `E4`, `N=2m`: `u=(0,0,m),v=(0,1,m+1)`; common distances `{m,m+1,m+2}`.

Since automorphisms preserve distance multisets and the condition of being outside S, all three-site sets with at least two corners fail outer resolution.

### Conclusion
Lemmas 1–3 exclude every three-site set. Lemma 0 excludes all smaller sets by a direct unit-cube argument. Therefore `odim(G_n)>=4` for all `n>=6` (computer-assisted proof candidate).

## Part II: upper bound
The earlier `No58_upper_symbolic_proof_v01.py` verifies a four-site witness for every `n>=6` by a finite exact reduction in the sums of distances and by explicit exceptions `n=6,8`. It was re-run in the current session. The candidate lower and upper bounds give the stated exact value, **provided both certificates pass independent audit**.

## Integrity and limits
- No large-n extrapolation is used for Lemma 1: the finite threshold is justified by an explicit collision-lifting lemma.
- The symbolic ordinal classification is genuinely independent of `n` and of the location of interior `t`, since only unit-cut masks enter its necessary condition.
- The algebraic witness identities are asserted over all parameter values in the stated branches; finite N test scripts are *supporting* checks, not a substitute for their algebraic verification.
- **Separate AI review (user-supplied, 2026-11-07):** v0.4 MODEL / COMPUTATION / INTEGRITY / overall PROOF reported PASS, with an explicit B(N)-even coverage omission and a missing written proof for |S|<=2. A previous separate report marked collision-witness independent rederivation PARTIAL, and the reviewer has not certified every repaired line of v0.5. Both scopes are retained rather than conflated. LITERATURE PARTIAL; NOVELTY INCONCLUSIVE.**
- **v0.5 arithmetic verification:** supplementary finite-difference checker `No58_v05_finite_difference_witness_certificate.py` verifies 24 affine case parametrizations (23 frozen formulas plus explicit B(N)-even), including exterior/distinctness/coordinate checks. `No58_v05_branch_coverage_audit.py` supplies inverse-slack branch mapping for all N>=5 and physically checks 268,528 patterns for N<=420. Both are same-collaboration author evidence, not a substitute for third-party independent proof verification.
- **Human peer review: NOT DONE. Novelty against the full literature: INCONCLUSIVE. GitHub/Zenodo release: HOLD.**
- This new 3D-grid candidate is **not** the earlier duplicate No.58 prism forcing paper; that prior duplicate remains NOT ADOPTED.


## Editorial addendum: related work and limitations (2026-11-07)

1. Gil-Pons, Ramírez-Cruz, Trujillo-Rasua, Yero, *Distance-based vertex identification in graphs: the outer multiset dimension*, Applied Mathematics and Computation 363 (2019), Article 124612, introduced the outer variant. See https://arxiv.org/abs/1902.03017.
2. Klavžar, Kuziak, Yero, *Further Contributions on the Outer Multiset Dimension of Graphs*, Results in Mathematics 78 (2023), Article 50, https://doi.org/10.1007/s00025-022-01829-8, established the exact value 3 for products of **two** nontrivial paths. No 3-factor exact formula is claimed in that paper's abstract.
3. Mora, Souto-Salorio, Tarrío-Tobar, *Resolving sets tolerant to failures in three-dimensional grids*, Mediterranean Journal of Mathematics 19 (2022), Article 188, https://doi.org/10.1007/s00009-022-02096-1, concerns **ordered** resolving sets / fault tolerance, not the 3D **outer multiset** value. The 2-site lower bound is supplied explicitly above as Lemma 0, independently of this citation.
4. Farhan, Klavžar, Kuziak, Yero, *Multiset resolvability parameters in graphs: A survey with new results and open problems*, arXiv:2607.10311 (11 July 2026), https://arxiv.org/html/2607.10311, explicitly lists as **Problem 10** an extension of its Theorem 4.9 from two paths to Cartesian products of more than two paths. The present theorem would solve only the **specific** family `P_2 □ P_3 □ P_n, n≥6`, not all products.
5. Araujo-Pardo, Dalfó, Olsen, Reyes, Simanjuntak, *On the outer multiset dimensions of graphs*, Bol. Soc. Mat. Mex. 32 (2026), Article 142, https://doi.org/10.1007/s40590-026-00973-3 (17 October 2026), studies related bounds/constructions. No direct identical 3D Cartesian path product was identified in its online text, but exhaustive equivalence analysis has not been completed.
6. Marcelo, Tolentino, Garciano, Buot, *On multiset dimension of cylindrical graphs*, Journal of Combinatorial Mathematics and Combinatorial Computing 126 (2025), 225–240, https://combinatorialpress.com/jcmcc-articles/volume-126/on-multiset-dimension-of-cylindrical-graphs/, concerns **ordinary** multiset dimension and **path × cycle** products. The underlying objects and parameter are not identical.
7. Bo Peng, *The Outer Multiset Dimension of Toroidal Grids*, arXiv:2609.20073 (September 2026), https://arxiv.org/abs/2609.20073, concerns **cycle × cycle**, not the three-path product here.

**Novelty assessment: INCONCLUSIVE.** These comparisons constrain plausible direct overlap; they do **not** establish priority against all post-survey preprints, implicit corollaries, theses, or different nomenclature. The work remains on release HOLD pending full prior-art audit and the author's express decision.


## v0.5 addendum: explicit all-parameter coverage of the A/B/C witness branches

Write `N=n-1>=5` and `m=floor(N/2)`. The extra v0.5 `B(N)` boundary branch is mathematically the **same witness identity** as the original B even `t>m` formula, but previously its free-slack encoding excluded `t=N`. Its independent algebraic certificate is branch 24. This corrects the certificate's domain, not the main theorem or the witness coordinates.

The following exhaustive branch partition is symbolic and valid for all N>=5, not merely the tested N values:

- **A:** t=0 -> 1; t=N -> 2; remaining even t -> 3; remaining odd t and odd N -> 4; remaining odd t and even N split t<m ->5, t>m ->6, t=m ->7.
- **B, even N:** t<m ->8; m<t<N ->9; t=m ->10; **t=N ->24**.
- **B, odd N:** t=1 ->11; odd t>=3 ->12 (including t=N); t=N-1 ->13; remaining even t<N-1 ->14 (including t=0).
- **C:** t=0 ->15; positive even t ->16; odd t ->17.
- **Exceptions:** E0,E1,E2,E3 ->18,19,20,21 for every N; E4 ->22 (odd N) or 23 (even N).

For each case the code `No58_v05_branch_coverage_audit.py` constructs nonnegative integers p,q from N,t via direct inverse formulas, calls the precise case construction, and checks a physical outer multiset collision on the actual grid. The inverse formulas establish the combinatorial coverage for arbitrarily large N; the finite N=5..420 check is a cross-check, not the logical premise. The ordinal-classification equivalence and the 35-layer compression remain exactly those in the frozen v0.3/Audit D sources. No historical independent reviewer verdict is retroactively modified.
