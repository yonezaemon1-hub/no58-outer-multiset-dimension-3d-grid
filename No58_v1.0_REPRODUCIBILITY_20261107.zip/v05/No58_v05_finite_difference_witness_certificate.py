#!/usr/bin/env python3
"""No.58 v0.5: supplementary finite-difference 24-branch witness checker.

Inputs are the 24 explicit case formulas in the manuscript, independently
transcribed here. Unlike the earlier Aff checker, this reconstructs coefficients
from *integer evaluation* at slack 0 and unit directions. It also verifies that
all absolute-value signs are constant on the full p,q>=0 orthant; only then can
unit evaluations prove the entire infinite-parameter identity.

No original audit modules, numpy, sympy or network access are used.
Throws on any unproved condition. Program never relies on `assert`.
"""
from itertools import product
import json


def require(ok, message):
    if not ok:
        raise RuntimeError('FAIL-CLOSED: ' + message)


def A(N,t): return ((0,0,0),(0,0,N),(0,2,t))
def B(N,t): return ((0,0,0),(0,0,N),(1,0,t))
def C(N,t): return ((0,0,0),(1,2,0),(0,2,t))

def E(j,N):
    return (
        ((0,0,0),(0,1,N),(0,2,0)),
        ((0,0,0),(0,1,N),(1,0,N)),
        ((0,0,0),(0,2,0),(1,0,0)),
        ((0,0,0),(0,2,0),(1,1,0)),
        ((0,0,0),(0,2,N),(1,0,N)),
    )[j]

# Each case is a separately transcribed formula evaluated only on integer
# nonnegative slack p,q. No source-code imports from earlier audits.
def case(j,p,q):
    if j== 1:
        N=5+p;t=0;S=A(N,t);u=(0,2,1);v=(1,0,0)
    elif j== 2:
        N=5+p;t=N;S=A(N,t);u=(0,2,N-1);v=(1,0,N)
    elif j== 3:
        k=1+p;t=2*k;N=t+1+q;S=A(N,t);u=(0,0,k);v=(0,1,k+1)
    elif j== 4:
        k=p;m=k+1+q;N=2*m+1;t=2*k+1;h=m+k+1;S=A(N,t);u=(0,0,h);v=(0,1,h-1)
    elif j== 5:
        t=1+p;m=t+1+q;N=2*m;S=A(N,t);u=(0,1,m+1);v=(1,0,m-1)
    elif j== 6:
        m=2+p+q;t=m+1+p;N=2*m;S=A(N,t);u=(0,1,m-1);v=(1,0,m+1)
    elif j== 7:
        m=3+p;t=m;N=2*m;S=A(N,t);u=(0,0,m-1);v=(0,0,m+1)
    elif j== 8:
        t=p;m=t+1+q;N=2*m;S=B(N,t);u=(0,1,m-1);v=(1,0,m+1)
    elif j== 9:
        m=2+p+q;t=m+1+p;N=2*m;S=B(N,t);u=(0,1,m+1);v=(1,0,m-1)
    elif j==10:
        m=3+p;t=m;N=2*m;S=B(N,t);u=(0,0,m-1);v=(0,0,m+1)
    elif j==11:
        m=2+p;N=2*m+1;t=1;S=B(N,t);u=(0,1,0);v=(1,1,1)
    elif j==12:
        k=1+p;m=k+q;N=2*m+1;t=2*k+1;S=B(N,t);u=(0,0,k);v=(1,0,k+1)
    elif j==13:
        m=2+p;N=2*m+1;t=N-1;S=B(N,t);u=(0,1,N);v=(1,1,N-1)
    elif j==14:
        k=p;m=k+1+q;N=2*m+1;t=2*k;h=m+k+1;S=B(N,t);u=(0,0,h);v=(1,0,h-1)
    elif j==15:
        N=5+p;t=0;S=C(N,t);u=(0,2,1);v=(1,0,0)
    elif j==16:
        k=1+p;t=2*k;N=t+q;S=C(N,t);u=(0,0,k);v=(0,1,k+1)
    elif j==17:
        k=p;t=2*k+1;N=t+q;S=C(N,t);u=(0,0,k+1);v=(1,0,k)
    elif j==18:
        N=5+p;t=0;S=E(0,N);u=(1,0,0);v=(1,2,0)
    elif j==19:
        N=5+p;t=0;S=E(1,N);u=(0,1,0);v=(1,0,0)
    elif j==20:
        N=5+p;t=0;S=E(2,N);u=(1,2,0);v=(0,0,1)
    elif j==21:
        N=5+p;t=0;S=E(3,N);u=(1,0,0);v=(1,2,0)
    elif j==22:
        m=2+p;N=2*m+1;t=0;S=E(4,N);u=(0,0,m);v=(1,0,m+1)
    elif j==23:
        m=3+p;N=2*m;t=0;S=E(4,N);u=(0,0,m);v=(0,1,m+1)
    elif j==24:
        # Previously missing boundary B(t), N even, t=N.
        # This exact witness is the t>m formula at t=N; no finite
        # extrapolation or reversal assumption is needed.
        m=3+p;N=2*m;t=N;S=B(N,t);u=(0,1,m+1);v=(1,0,m-1)
    else:
        raise RuntimeError('Unknown case')
    return N,t,S,u,v


def subtraction(a,b):return tuple(x-y for x,y in zip(a,b))
def nonnegative(a):return all(v>=0 for v in a)
def strictly_positive(a):return a[0]>0 and all(v>=0 for v in a)
def nonzero_ordered(a,b):
    for i in range(3):
        d=subtraction(a[i],b[i]); nd=tuple(-x for x in d)
        if strictly_positive(d) or strictly_positive(nd):return True
    return False


def absolute_affine(a, label):
    if nonnegative(a):return a
    neg=tuple(-x for x in a)
    if nonnegative(neg):return neg
    raise RuntimeError(f'FAIL-CLOSED: sign changes with slack for {label}: {a}')


def adder(a,b):return tuple(x+y for x,y in zip(a,b))


def eval_poly_tuple(j):
    # Build all required affine quantities from three independent integer
    # evaluations, not by inheriting arithmetic classes from any source.
    samples=[case(j,0,0),case(j,1,0),case(j,0,1)]
    # N coeffs from sample values
    N=(samples[0][0], samples[1][0]-samples[0][0], samples[2][0]-samples[0][0])
    t=(samples[0][1], samples[1][1]-samples[0][1], samples[2][1]-samples[0][1])
    def cval(which, k, axis):
        orig=samples[0][which][k][axis]; pa=samples[1][which][k][axis]; qb=samples[2][which][k][axis]
        return (orig,pa-orig,qb-orig)
    S=[[cval(2,k,a) for a in range(3)] for k in range(3)]
    u=[(samples[0][3][a],samples[1][3][a]-samples[0][3][a],samples[2][3][a]-samples[0][3][a]) for a in range(3)]
    v=[(samples[0][4][a],samples[1][4][a]-samples[0][4][a],samples[2][4][a]-samples[0][4][a]) for a in range(3)]
    require(len(S)==3,'sites !=3')
    bounds=((1,0,0),(2,0,0),N)
    for name,vertex in [('u',u),('v',v)]+[(f's{i}',s) for i,s in enumerate(S)]:
        for axis in range(3):
            require(nonnegative(vertex[axis]),f'{j} {name} coordinate below zero')
            require(nonnegative(subtraction(bounds[axis],vertex[axis])),f'{j} {name} exceeds bound')
    require(nonzero_ordered(u,v),f'{j} u==v for some slacks')
    for wname,w in [('u',u),('v',v)]:
        for k,s in enumerate(S):
            require(nonzero_ordered(w,s),f'{j} {wname} may coincide with site {k}')
    for a in range(3):
        for b in range(a+1,3):
            require(nonzero_ordered(S[a],S[b]),f'{j} duplicate sites')
    def vecdist(w,s,wname,k):
        acc=(0,0,0)
        for axis in range(3):
            acc=adder(acc,absolute_affine(subtraction(w[axis],s[axis]),f'{j} {wname} s{k} ax{axis}'))
        return acc
    lhs=sorted(vecdist(u,s,'u',k) for k,s in enumerate(S))
    rhs=sorted(vecdist(v,s,'v',k) for k,s in enumerate(S))
    require(lhs==rhs,f'{j} mismatch in affine distance multisets {lhs} vs {rhs}')
    # Confirm that reconstructing a coordinate from samples did not silently
    # assume affinity of the case formula. No division/abs in these formulas;
    # test 16 extra points per case, including non-diagonal slacks.
    for p,q in product((0,1,2,8),(0,1,3,9)):
        actual=case(j,p,q)
        def ev(a):return a[0]+a[1]*p+a[2]*q
        require(ev(N)==actual[0] and ev(t)==actual[1],f'{j} N,t not affine')
        for k,s in enumerate(S):
            require(tuple(ev(a) for a in s)==actual[2][k],f'{j} site formula not affine')
        require(tuple(ev(a) for a in u)==actual[3] and tuple(ev(a) for a in v)==actual[4],f'{j} endpoint not affine')
    return {'branch':j,'distance_multiset_affine':lhs,'guards':'proved from coefficient signs over p,q>=0','spotchecks':16}


def main():
    certificates=[eval_poly_tuple(j) for j in range(1,25)]
    # Deliberately corrupt an exterior endpoint in branch 20.  A verifier
    # which checks merely file integrity or finite sample success could miss
    # this; the arithmetic certificate must reject it.
    global case
    original=case
    def malicious(j,p,q):
        N,t,S,u,v=original(j,p,q)
        if j==20:
            u=(u[0],u[1]-1,u[2])
        return N,t,S,u,v
    case=malicious
    rejected=False
    try:
        eval_poly_tuple(20)
    except RuntimeError:
        rejected=True
    finally:
        case=original
    require(rejected,'mutation not detected by certificate checker')
    print('PASS: deliberate witness corruption rejected (negative control)')
    output={'scope':'23 original branches plus explicit boundary B(N) at even N; arithmetic only',
        'method':'finite differences reconstruct affine functions; coefficient-sign certificate for absolute values and vertex guards',
        'limitations':'branch coverage depends on separate ordinal classification and branch partition; not third-party peer review',
        'branches':certificates}
    with open('No58_v05_witness_certificate.json','w',encoding='utf8') as f:
        json.dump(output,f,ensure_ascii=False,indent=2)
    for entry in certificates:
        print('PASS branch',str(entry['branch']).zfill(2),'affine signature',entry['distance_multiset_affine'])
    print('PASS: 24/24 branches; valid outside collisions for all p,q>=0 within checked branch parametrizations')
    print('CONDITIONAL: relies on complete correspondence of parametrizations with all ordinal types')

if __name__=='__main__':main()
