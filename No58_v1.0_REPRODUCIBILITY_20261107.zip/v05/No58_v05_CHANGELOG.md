# No.58 v0.5 — changes from v0.4 (2026-11-07)

1. Added a self-contained unit-cube proof that no set with <=2 landmarks resolves the grid (Lemma 0). No dependence on an uncited metric-dimension-3 result.
2. Fixed incomplete B(t), N even, t=N *certificate coverage*: new case 24 explicitly proves the same old witness formula at the endpoint. Previous v0.4 case 9 covered only m<t<N.
3. Added exact inverse-slack all-N A/B/C/E branch mapping and an N=5..420 cross-check: 268,528 physical instances; all covered, zero invalid exterior collisions.
4. Retained all 23 preexisting affine identities and their frozen sources; no numerical or mathematical main-claim change.
5. Reconciled package scope: REVIEW_ONLY is standalone supplemental documentation and checks only (no frozen original archives); FULL_HOLD includes the original byte-for-byte v0.4 full archive, within which the original v0.3/Audit D ZIPs were independently hash-matched.
6. Checked 2026 Springer Araujo-Pardo et al. and 2025 Combinatorial Press Marcelo et al. bibliographic records on official publisher pages. Distinguished standard outer from *local outer* dimensions.
7. Removed raw Windows logs and user-specific filesystem paths from new v0.5 distribution.

Mathematics: author-side certificate checks PASS; independent AI review of v0.4 reported PROOF PASS with requested repairs. v0.5 repaired text is not yet independently re-audited. NOVELTY INCONCLUSIVE. RELEASE HOLD. No GitHub/Zenodo changes.
