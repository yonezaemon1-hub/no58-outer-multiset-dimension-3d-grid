# Windows 10 / PowerShell 5.1: v0.5 supplementary audit only

Unzip the `No58_v05_REVIEW_ONLY.zip` to a fresh local folder. In PowerShell, navigate to that folder and run:

```powershell
python -I .\No58_v05_finite_difference_witness_certificate.py
if ($LASTEXITCODE -ne 0) { throw 'FAIL: v0.5 24-branch arithmetic certificate' }
python -I .\No58_v05_branch_coverage_audit.py
if ($LASTEXITCODE -ne 0) { throw 'FAIL: v0.5 branch coverage audit' }
```

This is a source package, **not** an auto-executing or externally downloaded runner. `python -I` executes only local standard-library Python; coverage script explicitly imports the neighboring audited source from its own folder. The certificate regenerates its JSON; compare manifests on immutable files **before** running in the original folder or execute in a disposable working copy to avoid a manifest mismatch due to regeneration.

The original Windows Audit D PASS remains scoped to the original frozen package; do **not** report v0.5 Windows PASS until these new checks actually run locally.

Public release remains HOLD; personal Windows log paths are omitted.
